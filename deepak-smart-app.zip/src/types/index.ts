export type Language = 'hi' | 'en';
export type ThemeMode = 'light' | 'dark';

export type MainTab = 'home' | 'ai-assistant' | 'services' | 'my-files' | 'profile';

export type ServiceSubTab = 'all' | 'csc' | 'jobs' | 'business' | 'photo' | 'pdf';

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  avatarUrl?: string;
  isLoggedIn: boolean;
  isVip: boolean;
  aiCredits: number;
  role: 'user' | 'admin';
  joinedDate: string;
  shopName?: string;
  upiId?: string;
}

export interface SavedFile {
  id: string;
  title: string;
  type: 'pdf' | 'image' | 'invoice' | 'document';
  date: string;
  size: string;
  dataUrl: string;
  category: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  type: 'info' | 'alert' | 'success';
  linkTab?: MainTab;
}

export interface JobItem {
  id: string;
  title: string;
  department: string;
  totalPosts: string;
  qualification: string;
  ageLimit: string;
  lastDate: string;
  category: string;
  salary: string;
  officialUrl: string;
  status: string;
  featured?: boolean;
}

export interface CSCService {
  id: string;
  titleHi: string;
  titleEn: string;
  category: 'identity' | 'certificates' | 'welfare' | 'utility';
  descriptionHi: string;
  descriptionEn: string;
  officialPortal: string;
  officialPortalName: string;
  requiredDocsHi: string[];
  requiredDocsEn: string[];
  estimatedDays: string;
  govtFee: string;
  stepsHi: string[];
  stepsEn: string[];
  iconName: string;
}

export interface QuizQuestion {
  id: number;
  questionHi: string;
  questionEn: string;
  optionsHi: string[];
  optionsEn: string[];
  correctIndex: number;
  explanationHi: string;
  explanationEn: string;
}

export interface InvoiceItem {
  description: string;
  quantity: number;
  rate: number;
  amount: number;
}
