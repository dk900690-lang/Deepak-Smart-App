import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AndroidStatusBar } from './components/layout/AndroidStatusBar';
import { Header } from './components/layout/Header';
import { BottomNav } from './components/layout/BottomNav';
import { HomeScreen } from './components/screens/HomeScreen';
import { AIAssistantScreen } from './components/screens/AIAssistantScreen';
import { ServicesHubScreen } from './components/screens/ServicesHubScreen';
import { MyFilesScreen } from './components/screens/MyFilesScreen';
import { ProfileScreen } from './components/screens/ProfileScreen';
import { VoiceActionModal } from './components/common/VoiceActionModal';
import { AdminPanelModal } from './components/screens/AdminPanelModal';
import { FlutterExportModal } from './components/screens/FlutterExportModal';
import { VipModal } from './components/screens/VipModal';
import { SplashScreen } from './components/common/SplashScreen';

const MainAppContent: React.FC = () => {
  const { currentTab, isAndroidFrame, theme } = useApp();
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  const renderActiveScreen = () => {
    switch (currentTab) {
      case 'home':
        return <HomeScreen />;
      case 'ai-assistant':
        return <AIAssistantScreen />;
      case 'services':
        return <ServicesHubScreen />;
      case 'my-files':
        return <MyFilesScreen />;
      case 'profile':
        return <ProfileScreen />;
      default:
        return <HomeScreen />;
    }
  };

  return (
    <div
      className={`min-h-screen ${
        theme === 'dark' ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'
      } flex items-center justify-center p-0 sm:p-4 transition-colors duration-200`}
    >
      {/* Container: If Android Frame is enabled, render phone casing with bezel and shadow */}
      <div
        className={`w-full ${
          isAndroidFrame
            ? 'max-w-[420px] h-[100dvh] sm:h-[880px] sm:rounded-[44px] sm:ring-[10px] sm:ring-slate-800 sm:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.5)]'
            : 'max-w-md min-h-screen'
        } bg-[#F8FAFC] dark:bg-slate-950 flex flex-col relative overflow-hidden transition-all duration-300`}
      >
        {/* Android Status Bar */}
        <AndroidStatusBar />

        {/* Global App Header */}
        <Header />

        {/* Scrollable Screen Content */}
        <main className="flex-1 overflow-y-auto no-scrollbar relative">
          {renderActiveScreen()}
        </main>

        {/* 5-Tab Floating Bottom Navigation Bar */}
        <BottomNav />

        {/* Global Modals */}
        <VoiceActionModal />
        <AdminPanelModal />
        <FlutterExportModal />
        <VipModal />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
