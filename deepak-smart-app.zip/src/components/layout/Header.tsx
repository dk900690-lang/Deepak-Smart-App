import React, { useState } from 'react';
import {
  Bell,
  Languages,
  Moon,
  Sun,
  Shield,
  Crown,
  Mic,
  CheckCircle,
  X,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const Header: React.FC = () => {
  const {
    language,
    setLanguage,
    theme,
    setTheme,
    user,
    notifications,
    markNotificationRead,
    setIsVoiceModalOpen,
    setIsAdminModalOpen,
    setIsVipModalOpen,
    setCurrentTab,
  } = useApp();

  const [showNotifications, setShowNotifications] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <header className="relative w-full bg-gradient-to-r from-[#102A43] via-[#0C2135] to-[#102A43] text-white px-3 sm:px-4 py-2.5 shadow-md border-b border-orange-500/20 z-40 select-none">
      <div className="flex items-center justify-between">
        {/* Brand Logo & Name */}
        <div
          onClick={() => setCurrentTab('home')}
          className="flex items-center space-x-2.5 cursor-pointer group"
        >
          <div className="relative w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 via-orange-500 to-amber-600 p-0.5 shadow-md shadow-orange-500/30 flex items-center justify-center transform group-hover:scale-105 transition">
            <div className="w-full h-full bg-[#102A43] rounded-[10px] flex items-center justify-center relative overflow-hidden">
              <span className="text-xl font-black bg-gradient-to-br from-amber-400 via-orange-400 to-yellow-300 bg-clip-text text-transparent">
                D
              </span>
              <div className="absolute -bottom-1 w-full h-1 bg-gradient-to-r from-orange-500 via-white to-green-600"></div>
            </div>
          </div>

          <div>
            <div className="flex items-center space-x-1.5">
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-white flex items-center">
                Deepak <span className="text-orange-400 ml-1">Smart</span>
              </h1>
              {user.isVip && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsVipModalOpen(true);
                  }}
                  className="px-1.5 py-0.5 rounded-full bg-amber-400/20 border border-amber-400/40 text-[9px] font-bold text-amber-300 flex items-center space-x-0.5 hover:bg-amber-400/30 transition"
                >
                  <Crown className="w-2.5 h-2.5 text-amber-400" />
                  <span>VIP</span>
                </button>
              )}
            </div>
            <p className="text-[10px] text-orange-200/80 font-medium line-clamp-1">
              {language === 'hi' ? 'आपका अपना डिजिटल स्मार्ट साथी' : 'Your Digital Smart Companion'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-1.5 sm:space-x-2">
          {/* Voice to Action Shortcut */}
          <button
            onClick={() => setIsVoiceModalOpen(true)}
            title="Voice-to-Action Command"
            className="p-1.5 rounded-full bg-orange-500 hover:bg-orange-600 text-white shadow-sm shadow-orange-500/40 relative active:scale-95 transition flex items-center justify-center"
          >
            <Mic className="w-4 h-4" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
          </button>

          {/* Language Toggle */}
          <button
            onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
            className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-semibold text-white/90 border border-white/10 flex items-center space-x-1 transition active:scale-95"
            title="भाषा बदलें (Change Language)"
          >
            <Languages className="w-3.5 h-3.5 text-orange-400" />
            <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white/90 border border-white/10 transition active:scale-95"
            title="Dark/Light Mode"
          >
            {theme === 'light' ? (
              <Moon className="w-3.5 h-3.5 text-amber-300" />
            ) : (
              <Sun className="w-3.5 h-3.5 text-amber-400" />
            )}
          </button>

          {/* Notifications Bell */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white/90 border border-white/10 relative transition active:scale-95"
              title="सूचनाएं (Notifications)"
            >
              <Bell className="w-3.5 h-3.5 text-orange-300" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-orange-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center shadow">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notifications Dropdown Drawer */}
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="p-3 bg-gradient-to-r from-orange-500 to-amber-600 text-white flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Bell className="w-4 h-4" />
                    <span className="font-bold text-sm">
                      {language === 'hi' ? 'महत्वपूर्ण सूचनाएं' : 'Important Alerts'}
                    </span>
                  </div>
                  <button
                    onClick={() => setShowNotifications(false)}
                    className="p-1 hover:bg-white/20 rounded-full"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                  {notifications.length === 0 ? (
                    <div className="p-6 text-center text-xs text-slate-400">
                      कोई नई सूचना नहीं है (No notifications)
                    </div>
                  ) : (
                    notifications.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => {
                          markNotificationRead(item.id);
                          if (item.linkTab) setCurrentTab(item.linkTab);
                          setShowNotifications(false);
                        }}
                        className={`p-3 text-xs cursor-pointer hover:bg-orange-50/50 dark:hover:bg-slate-800/60 transition ${
                          !item.read
                            ? 'bg-orange-50/30 dark:bg-slate-800/30 font-medium'
                            : 'opacity-80'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-slate-900 dark:text-white flex items-center space-x-1">
                            {item.type === 'alert' ? (
                              <span className="w-2 h-2 rounded-full bg-red-500 inline-block"></span>
                            ) : (
                              <CheckCircle className="w-3 h-3 text-green-500 inline" />
                            )}
                            <span>{item.title}</span>
                          </span>
                          <span className="text-[10px] text-slate-400">{item.date}</span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                          {item.message}
                        </p>
                      </div>
                    ))
                  )}
                </div>

                <div className="p-2.5 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 text-center">
                  <button
                    onClick={() => {
                      setCurrentTab('services');
                      setShowNotifications(false);
                    }}
                    className="text-[11px] font-semibold text-orange-600 dark:text-orange-400 hover:underline flex items-center justify-center space-x-1 w-full"
                  >
                    <span>{language === 'hi' ? 'सभी सरकारी अपडेट्स देखें' : 'View All Govt Updates'}</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Admin Dashboard Shield */}
          <button
            onClick={() => setIsAdminModalOpen(true)}
            className="p-1.5 rounded-lg bg-orange-600/30 hover:bg-orange-600/50 text-orange-300 border border-orange-500/40 transition active:scale-95"
            title="Admin Control Panel"
          >
            <Shield className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
