import React, { useState, useEffect } from 'react';
import { Wifi, Signal, Battery, Smartphone } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AndroidStatusBar: React.FC = () => {
  const { isAndroidFrame, setIsAndroidFrame } = useApp();
  const [timeStr, setTimeStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full bg-[#102A43] text-white text-[11px] font-medium px-4 py-1.5 flex items-center justify-between select-none z-50 border-b border-white/10 shrink-0">
      {/* Left: Time & Provider */}
      <div className="flex items-center space-x-2">
        <span className="font-semibold tracking-tight">{timeStr || '10:45 AM'}</span>
        <span className="hidden sm:inline-block text-[10px] text-orange-400 font-semibold uppercase tracking-wider">
          Jio 5G True
        </span>
      </div>

      {/* Center: Punch Hole Camera Simulator */}
      <div className="flex items-center space-x-1.5">
        <div className="w-3.5 h-3.5 rounded-full bg-black ring-1 ring-white/20 shadow-inner flex items-center justify-center">
          <div className="w-1 h-1 rounded-full bg-blue-900/80"></div>
        </div>
      </div>

      {/* Right: Network Signals, WiFi, Battery & Frame Switcher */}
      <div className="flex items-center space-x-2.5">
        <button
          onClick={() => setIsAndroidFrame((prev: boolean) => !prev)}
          title={isAndroidFrame ? 'Switch to Fullscreen Responsive' : 'Switch to Android Device Frame'}
          className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 hover:bg-white/20 text-orange-300 font-medium flex items-center space-x-1 transition"
        >
          <Smartphone className="w-2.5 h-2.5" />
          <span className="text-[9px]">{isAndroidFrame ? 'Phone Frame' : 'Full Web'}</span>
        </button>

        <Wifi className="w-3.5 h-3.5 text-white/90" />
        <Signal className="w-3.5 h-3.5 text-white/90" />
        <div className="flex items-center space-x-1">
          <span className="text-[10px] font-bold text-green-400">98%</span>
          <Battery className="w-3.5 h-3.5 text-green-400 rotate-90" />
        </div>
      </div>
    </div>
  );
};
