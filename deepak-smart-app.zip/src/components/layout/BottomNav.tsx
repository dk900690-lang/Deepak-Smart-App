import React from 'react';
import { Home, Bot, Grid3X3, FolderCheck, User } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MainTab } from '../../types';

export const BottomNav: React.FC = () => {
  const { currentTab, setCurrentTab, language, savedFiles } = useApp();

  const tabs: { id: MainTab; labelHi: string; labelEn: string; icon: React.FC<{ className?: string }>; badge?: number }[] = [
    {
      id: 'home',
      labelHi: 'होम',
      labelEn: 'Home',
      icon: Home,
    },
    {
      id: 'ai-assistant',
      labelHi: 'दीपक AI',
      labelEn: 'Deepak AI',
      icon: Bot,
    },
    {
      id: 'services',
      labelHi: 'सेवाएं',
      labelEn: 'Services',
      icon: Grid3X3,
    },
    {
      id: 'my-files',
      labelHi: 'माय फाइल्स',
      labelEn: 'My Files',
      icon: FolderCheck,
      badge: savedFiles.length,
    },
    {
      id: 'profile',
      labelHi: 'प्रोफाइल',
      labelEn: 'Profile',
      icon: User,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto w-full bg-white/95 dark:bg-[#102A43]/95 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] dark:shadow-[0_-4px_25px_rgba(0,0,0,0.4)] z-40 px-2 py-1 select-none">
      <div className="flex items-center justify-around">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;
          const Icon = tab.icon;
          const label = language === 'hi' ? tab.labelHi : tab.labelEn;

          return (
            <button
              key={tab.id}
              onClick={() => {
                // Gentle tactile feedback if supported
                if ('vibrate' in navigator) {
                  try {
                    navigator.vibrate(20);
                  } catch (e) {}
                }
                setCurrentTab(tab.id);
              }}
              className={`flex-1 py-1.5 flex flex-col items-center justify-center relative transition-all duration-200 ${
                isActive
                  ? 'text-orange-600 dark:text-orange-400 font-bold scale-105'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
              }`}
            >
              {/* Highlight Pill for Active Tab */}
              {isActive && (
                <span className="absolute top-0 w-8 h-1 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full shadow-sm"></span>
              )}

              <div className="relative p-1">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? 'scale-110 stroke-[2.4]' : 'stroke-[1.8]'
                  }`}
                />
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-0.5 -right-1 w-4 h-4 bg-orange-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center shadow">
                    {tab.badge}
                  </span>
                )}
                {tab.id === 'ai-assistant' && !isActive && (
                  <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-orange-400 animate-ping"></span>
                )}
              </div>

              <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-[64px]">
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
