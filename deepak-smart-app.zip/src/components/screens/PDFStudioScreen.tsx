import React, { useState, useRef } from 'react';
import {
  FileText,
  Upload,
  Download,
  Scan,
  Sparkles,
  BookOpen,
  Volume2,
  Trash2,
  Plus,
  CheckCircle,
  FileDown,
  Layers,
  Copy,
  Check,
  Loader2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { jsPDF } from 'jspdf';

export const PDFStudioScreen: React.FC = () => {
  const { language, saveFile } = useApp();

  const [activeTab, setActiveTab] = useState<'img-to-pdf' | 'scanner' | 'reader' | 'text-to-pdf'>('img-to-pdf');

  // Image to PDF states
  const [images, setImages] = useState<string[]>([]);
  const [pdfTitle, setPdfTitle] = useState('Govt_Application_Documents');

  // Scanner states
  const [scannedImage, setScannedImage] = useState<string | null>(null);
  const [filterMode, setFilterMode] = useState<'bw' | 'grayscale' | 'enhanced'>('enhanced');

  // Hindi Document Reader states
  const [docText, setDocText] = useState('');
  const [readerExplanation, setReaderExplanation] = useState('');
  const [isExplaining, setIsExplaining] = useState(false);
  const [readerImage, setReaderImage] = useState<string | null>(null);

  // Text to PDF states
  const [textContent, setTextContent] = useState('');
  const [textHeading, setTextHeading] = useState('सेवा में / To Whom It May Concern');

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const scannerInputRef = useRef<HTMLInputElement>(null);
  const readerInputRef = useRef<HTMLInputElement>(null);

  // 1. Image to PDF multi-upload
  const handleMultipleImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        setImages((prev) => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const generateImageToPdf = () => {
    if (images.length === 0) return;

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    images.forEach((imgData, index) => {
      if (index > 0) {
        pdf.addPage();
      }
      // Header
      pdf.setFontSize(10);
      pdf.setTextColor(150, 150, 150);
      pdf.text(`Deepak Smart App Document - Page ${index + 1} of ${images.length}`, 15, 12);

      // Fit image onto A4 page (width 180mm, height 260mm)
      pdf.addImage(imgData, 'JPEG', 15, 18, 180, 255);
    });

    const fileName = `${pdfTitle || 'Document'}_${Date.now()}.pdf`;
    pdf.save(fileName);

    saveFile({
      title: fileName,
      type: 'pdf',
      size: `${(images.length * 180).toFixed(0)} KB`,
      dataUrl: '',
      category: 'PDF Studio',
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  // 2. Hindi Document Reader (Smart Bharat Mode)
  const handleExplainDocument = async () => {
    if (!docText && !readerImage) return;

    setIsExplaining(true);
    setReaderExplanation('');

    try {
      const res = await fetch('/api/ai/document-explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: docText,
          imageBase64: readerImage,
        }),
      });
      const data = await res.json();
      setReaderExplanation(data.summary || 'सारांश तैयार नहीं हो सका।');
    } catch (e: any) {
      setReaderExplanation('त्रुटि: ' + e.message);
    } finally {
      setIsExplaining(false);
    }
  };

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const clean = text.replace(/[*#_~`]/g, '');
      const u = new SpeechSynthesisUtterance(clean);
      u.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
      window.speechSynthesis.speak(u);
    }
  };

  // 3. Text to PDF
  const handleTextToPdf = () => {
    if (!textContent.trim()) return;

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    // Header styling
    pdf.setFontSize(16);
    pdf.setTextColor(16, 42, 67);
    pdf.text(textHeading || 'Document', 20, 25);

    pdf.setFontSize(10);
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Created with Deepak Smart App - Date: ${new Date().toLocaleDateString()}`, 20, 32);

    pdf.setDrawColor(255, 140, 0);
    pdf.setLineWidth(0.5);
    pdf.line(20, 35, 190, 35);

    // Body text
    pdf.setFontSize(11);
    pdf.setTextColor(30, 30, 30);
    const splitLines = pdf.splitTextToSize(textContent, 170);
    pdf.text(splitLines, 20, 45);

    const fileName = `Text_Document_${Date.now()}.pdf`;
    pdf.save(fileName);

    saveFile({
      title: fileName,
      type: 'pdf',
      size: '48 KB',
      dataUrl: '',
      category: 'PDF Studio',
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto select-none space-y-3.5">
      {/* Studio Header */}
      <div className="bg-gradient-to-r from-red-500 via-rose-500 to-red-600 rounded-3xl p-4 text-white shadow-lg flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white ring-2 ring-white/30 shadow-inner">
            <FileText className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
              Smart PDF & Docs
            </h2>
            <p className="text-xs text-red-100 font-medium">
              {language === 'hi'
                ? 'इमेज टू PDF, स्कैनर, हिंदी रीडर'
                : 'Image to PDF, Scanner & Hindi Reader'}
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-4 gap-1.5 bg-slate-200/80 dark:bg-slate-800 p-1 rounded-2xl text-[10px] sm:text-[11px] font-bold">
        {[
          { id: 'img-to-pdf', labelHi: 'इमेज टू PDF', labelEn: 'Img to PDF' },
          { id: 'scanner', labelHi: 'डॉक स्कैनर', labelEn: 'Doc Scanner' },
          { id: 'reader', labelHi: 'हिंदी रीडर', labelEn: 'Hindi Reader' },
          { id: 'text-to-pdf', labelHi: 'टेक्स्ट टू PDF', labelEn: 'Text to PDF' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`py-2 rounded-xl text-center transition ${
              activeTab === tab.id
                ? 'bg-white dark:bg-slate-900 text-red-600 dark:text-red-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            {language === 'hi' ? tab.labelHi : tab.labelEn}
          </button>
        ))}
      </div>

      {/* TAB 1: Image to PDF */}
      {activeTab === 'img-to-pdf' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4">
          <div>
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {language === 'hi' ? 'फोटो से PDF बनाएं' : 'Convert Images to PDF'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {language === 'hi'
                ? 'आधार कार्ड, मार्कशीट, या प्रमाण पत्र की फोटो जोड़ें और एक संयुक्त PDF बनाएं।'
                : 'Add Aadhaar, marksheets, or certificates and combine into one PDF.'}
            </p>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1">
              {language === 'hi' ? 'PDF फाइल का नाम:' : 'PDF File Name:'}
            </label>
            <input
              type="text"
              value={pdfTitle}
              onChange={(e) => setPdfTitle(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white px-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-slate-700"
            />
          </div>

          {/* Upload Box */}
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            multiple
            className="hidden"
            onChange={handleMultipleImages}
          />
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-red-300 dark:border-red-900/60 rounded-2xl p-6 text-center cursor-pointer hover:bg-red-50/50 dark:hover:bg-slate-800/50 transition"
          >
            <Upload className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-xs font-bold text-slate-800 dark:text-white">
              {language === 'hi' ? 'दस्तावेज़ की फोटो चुनें' : 'Choose Document Photos'}
            </p>
            <p className="text-[10px] text-slate-500 mt-0.5">
              (JPG, PNG, JPEG समर्थित - एक साथ कई फोटो चुन सकते हैं)
            </p>
          </div>

          {/* Preview of added pages */}
          {images.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span>
                  {language === 'hi' ? `कुल पेज: ${images.length}` : `Total Pages: ${images.length}`}
                </span>
                <button
                  onClick={() => setImages([])}
                  className="text-red-500 text-[10px] hover:underline"
                >
                  {language === 'hi' ? 'सभी हटाएं' : 'Clear All'}
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto p-1">
                {images.map((img, i) => (
                  <div
                    key={i}
                    className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 group h-24 bg-slate-100"
                  >
                    <img src={img} alt={`Page ${i + 1}`} className="w-full h-full object-cover" />
                    <span className="absolute bottom-1 left-1 bg-black/60 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">
                      P.{i + 1}
                    </span>
                    <button
                      onClick={() => setImages((prev) => prev.filter((_, idx) => idx !== i))}
                      className="absolute top-1 right-1 p-1 bg-red-600 text-white rounded-full opacity-80 hover:opacity-100"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>

              <button
                onClick={generateImageToPdf}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-red-500 to-rose-600 text-white text-xs font-bold shadow-md hover:from-red-600 hover:to-rose-700 transition flex items-center justify-center space-x-1.5 active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>
                  {language === 'hi' ? 'PDF डाउनलोड करें' : 'Generate & Download PDF'}
                </span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Document Scanner Filter */}
      {activeTab === 'scanner' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4">
          <div>
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {language === 'hi' ? 'मोबाइल डॉक्यूमेंट स्कैनर' : 'Mobile Document Scanner'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {language === 'hi'
                ? 'कैमरे की फोटो से परछाई (shadow) हटाकर साफ हाई-कंट्रास्ट स्कैन कॉपी बनाएं।'
                : 'Remove shadows and boost contrast for crystal clear scan copies.'}
            </p>
          </div>

          <input
            type="file"
            ref={scannerInputRef}
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                const reader = new FileReader();
                reader.onload = () => setScannedImage(reader.result as string);
                reader.readAsDataURL(file);
              }
            }}
          />

          {!scannedImage ? (
            <div
              onClick={() => scannerInputRef.current?.click()}
              className="border-2 border-dashed border-red-300 dark:border-red-900/60 rounded-2xl p-8 text-center cursor-pointer hover:bg-red-50/50 dark:hover:bg-slate-800/50 transition"
            >
              <Scan className="w-8 h-8 text-red-500 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-800 dark:text-white">
                {language === 'hi' ? 'कागज़/दस्तावेज़ की फोटो लें या चुनें' : 'Snap or Upload Document'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-center bg-slate-100 dark:bg-slate-800 p-2 rounded-2xl max-h-64 overflow-hidden border">
                <img
                  src={scannedImage}
                  alt="Scanned Preview"
                  className={`max-h-56 object-contain rounded-lg ${
                    filterMode === 'bw'
                      ? 'contrast-200 grayscale brightness-110'
                      : filterMode === 'grayscale'
                      ? 'grayscale contrast-125'
                      : 'contrast-125 brightness-105'
                  }`}
                />
              </div>

              {/* Filter controls */}
              <div className="grid grid-cols-3 gap-2 text-center">
                {[
                  { id: 'enhanced', label: 'Magic Color' },
                  { id: 'bw', label: 'B&W Scan' },
                  { id: 'grayscale', label: 'Grayscale' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setFilterMode(f.id as any)}
                    className={`py-1.5 rounded-xl text-[11px] font-bold border transition ${
                      filterMode === f.id
                        ? 'bg-red-500 text-white border-red-500 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setScannedImage(null)}
                  className="py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold"
                >
                  {language === 'hi' ? 'दूसरी फोटो लें' : 'Retake'}
                </button>
                <button
                  onClick={() => {
                    const pdf = new jsPDF();
                    pdf.addImage(scannedImage, 'JPEG', 15, 20, 180, 240);
                    pdf.save(`Scanned_Doc_${Date.now()}.pdf`);
                    saveFile({
                      title: 'Scanned Document.pdf',
                      type: 'pdf',
                      size: '110 KB',
                      dataUrl: '',
                      category: 'Scanner',
                    });
                    setSavedSuccess(true);
                    setTimeout(() => setSavedSuccess(false), 2500);
                  }}
                  className="py-2 rounded-xl bg-red-500 hover:bg-red-600 text-white text-xs font-bold shadow transition"
                >
                  {language === 'hi' ? 'स्कैन PDF सेव करें' : 'Save Scanned PDF'}
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Smart Bharat Mode - Hindi Document Reader */}
      {activeTab === 'reader' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3.5">
          <div>
            <div className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 text-[10px] font-bold mb-1">
              <Sparkles className="w-3 h-3" />
              <span>Smart Bharat Feature</span>
            </div>
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {language === 'hi' ? 'स्मार्ट हिंदी दस्तावेज़ पाठक' : 'Smart Hindi Document Reader'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {language === 'hi'
                ? 'सरकारी नोटिस, कोर्ट का आदेश या जटिल पत्र अपलोड करें—दीपक AI उसे सीधी व सरल हिंदी में समझाएगा।'
                : 'Upload legal/govt notices to get a simplified explanation in plain Hindi.'}
            </p>
          </div>

          <input
            type="file"
            ref={readerInputRef}
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                const reader = new FileReader();
                reader.onload = () => setReaderImage(reader.result as string);
                reader.readAsDataURL(file);
              }
            }}
          />

          <div className="flex items-center space-x-2">
            <button
              onClick={() => readerInputRef.current?.click()}
              className="py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center space-x-1"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>{readerImage ? 'दस्तावेज़ बदला गया' : 'कागज़ की फोटो अपलोड करें'}</span>
            </button>
            {readerImage && (
              <span className="text-[10px] text-green-600 font-semibold">✓ फोटो लोड हो गई</span>
            )}
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1">
              {language === 'hi' ? 'या नोटिस का टेक्स्ट यहाँ पेस्ट करें:' : 'Or paste notice text here:'}
            </label>
            <textarea
              rows={3}
              value={docText}
              onChange={(e) => setDocText(e.target.value)}
              placeholder="जैसे: सर्वसाधारण को सूचित किया जाता है कि राजस्व एवं भूमि सुधार विभाग द्वारा..."
              className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white p-2.5 rounded-xl text-xs border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-red-500"
            />
          </div>

          <button
            onClick={handleExplainDocument}
            disabled={isExplaining || (!docText && !readerImage)}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-red-500 to-amber-500 text-white text-xs font-bold shadow hover:from-red-600 hover:to-amber-600 transition flex items-center justify-center space-x-1.5 disabled:opacity-50"
          >
            {isExplaining ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>दीपक AI दस्तावेज़ समझ रहा है...</span>
              </>
            ) : (
              <>
                <BookOpen className="w-4 h-4" />
                <span>सरल हिंदी में समझें (Explain in Plain Hindi)</span>
              </>
            )}
          </button>

          {/* Explanation Output */}
          {readerExplanation && (
            <div className="p-3 bg-amber-50 dark:bg-slate-800/80 rounded-2xl border border-amber-200 dark:border-slate-700 space-y-2 animate-in fade-in">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-amber-700 dark:text-amber-400">
                  📢 सरल हिंदी व्याख्या (Explanation)
                </span>
                <button
                  onClick={() => speakText(readerExplanation)}
                  className="p-1 rounded bg-amber-100 hover:bg-amber-200 text-amber-800"
                  title="बोलकर सुनें"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
              <div className="text-xs text-slate-800 dark:text-slate-100 whitespace-pre-wrap leading-relaxed font-sans">
                {readerExplanation}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: Text to PDF */}
      {activeTab === 'text-to-pdf' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3.5">
          <div>
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {language === 'hi' ? 'टेक्स्ट से साफ PDF बनाएं' : 'Compose Text to PDF'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {language === 'hi'
                ? 'अपने नोट्स या आवेदन पत्र लिखें और पेशेवर A4 PDF के रूप में डाउनलोड करें।'
                : 'Write notes or official letters and export formatted A4 PDF.'}
            </p>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1">
              {language === 'hi' ? 'दस्तावेज़ का शीर्षक (Header):' : 'Document Title:'}
            </label>
            <input
              type="text"
              value={textHeading}
              onChange={(e) => setTextHeading(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white px-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-slate-700"
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1">
              {language === 'hi' ? 'मुख्य सामग्री (Content):' : 'Main Content:'}
            </label>
            <textarea
              rows={8}
              value={textContent}
              onChange={(e) => setTextContent(e.target.value)}
              placeholder="यहाँ टाइप करें या कॉपी-पेस्ट करें..."
              className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white p-3 rounded-xl text-xs border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-red-500"
            />
          </div>

          <button
            onClick={handleTextToPdf}
            disabled={!textContent.trim()}
            className="w-full py-2.5 rounded-xl bg-red-500 hover:bg-red-600 disabled:opacity-50 text-white text-xs font-bold shadow transition flex items-center justify-center space-x-1.5"
          >
            <Download className="w-4 h-4" />
            <span>{language === 'hi' ? 'PDF डाउनलोड करें' : 'Download Text as PDF'}</span>
          </button>
        </div>
      )}

      {savedSuccess && (
        <div className="p-2.5 rounded-xl bg-green-50 text-green-700 text-xs font-semibold flex items-center justify-center space-x-1.5 animate-in fade-in duration-200">
          <CheckCircle className="w-4 h-4 text-green-600" />
          <span>
            {language === 'hi'
              ? 'PDF डाउनलोड हो गया और "माय फाइल्स" में सुरक्षित सेव हो गया!'
              : 'PDF downloaded and saved to My Files!'}
          </span>
        </div>
      )}
    </div>
  );
};
