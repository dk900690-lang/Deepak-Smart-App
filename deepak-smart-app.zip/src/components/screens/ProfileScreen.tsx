import React, { useState } from 'react';
import {
  User,
  Crown,
  Languages,
  Moon,
  Sun,
  Shield,
  Smartphone,
  Sparkles,
  Download,
  Code,
  FileCheck,
  CheckCircle,
  LogOut,
  ExternalLink,
  Zap,
  PlayCircle,
  HelpCircle,
  Building,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ProfileScreen: React.FC = () => {
  const {
    language,
    setLanguage,
    theme,
    setTheme,
    isAndroidFrame,
    setIsAndroidFrame,
    user,
    setUser,
    addCredits,
    setIsVipModalOpen,
    setIsExportModalOpen,
    setIsAdminModalOpen,
  } = useApp();

  const [isAdPlaying, setIsAdPlaying] = useState(false);
  const [adTimer, setAdTimer] = useState(5);
  const [adEarned, setAdEarned] = useState(false);

  // Rewarded Ad Simulation
  const watchRewardedAd = () => {
    setIsAdPlaying(true);
    setAdTimer(5);
    const interval = setInterval(() => {
      setAdTimer((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsAdPlaying(false);
          addCredits(10);
          setAdEarned(true);
          setTimeout(() => setAdEarned(false), 3000);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto select-none space-y-3.5">
      {/* Profile Card */}
      <div className="bg-gradient-to-br from-[#102A43] via-[#16385C] to-[#0A1B2D] rounded-3xl p-5 text-white shadow-xl relative overflow-hidden border border-orange-500/20">
        <div className="flex items-center space-x-3.5 relative z-10">
          <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-400 to-orange-500 p-0.5 shadow-md shrink-0">
            <img
              src={user.avatarUrl}
              alt={user.name}
              className="w-full h-full object-cover rounded-[14px]"
            />
            {user.isVip && (
              <span className="absolute -bottom-1 -right-1 bg-amber-400 text-[#102A43] text-[9px] font-black px-1.5 rounded-full ring-2 ring-[#102A43] flex items-center space-x-0.5">
                <Crown className="w-2.5 h-2.5" />
                <span>VIP</span>
              </span>
            )}
          </div>

          <div className="space-y-0.5">
            <h2 className="text-base sm:text-lg font-bold tracking-tight">{user.name}</h2>
            <p className="text-xs text-orange-200">{user.email}</p>
            <p className="text-[11px] text-slate-300 font-medium">{user.shopName}</p>
            <span className="inline-block mt-1 text-[10px] px-2 py-0.5 rounded-full bg-green-500/20 text-green-300 font-bold border border-green-500/30">
              Verified CSC Operator
            </span>
          </div>
        </div>

        {/* AI Credits & VIP row */}
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
          <div>
            <span className="text-[10px] text-slate-400 block">AI असिस्टेंट क्रेडिट्स:</span>
            <span className="font-extrabold text-amber-400 text-sm">
              {user.isVip ? 'अनलिमिटेड (VIP)' : `${user.aiCredits} Credits`}
            </span>
          </div>

          <button
            onClick={watchRewardedAd}
            disabled={isAdPlaying}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold text-xs shadow hover:from-orange-600 transition flex items-center space-x-1"
          >
            <PlayCircle className="w-3.5 h-3.5" />
            <span>+10 फ्री क्रेडिट्स</span>
          </button>
        </div>
      </div>

      {adEarned && (
        <div className="p-2.5 rounded-xl bg-green-50 text-green-700 text-xs font-semibold flex items-center justify-center space-x-1.5 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-green-600" />
          <span>बधाई! आपको +10 AI क्रेडिट्स मिल गए हैं।</span>
        </div>
      )}

      {/* VIP Upgrade Banner */}
      <div
        onClick={() => setIsVipModalOpen(true)}
        className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 rounded-3xl p-4 text-white shadow-md cursor-pointer hover:shadow-lg transition relative overflow-hidden"
      >
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <div className="flex items-center space-x-1.5 text-xs font-extrabold">
              <Crown className="w-4 h-4 text-yellow-200" />
              <span>DEEPAK SMART VIP MEMBERSHIP</span>
            </div>
            <p className="text-xs text-orange-100">
              {language === 'hi'
                ? 'अनलिमिटेड AI सवाल, अल्ट्रा HD फोटो और प्राथमिकता सपोर्ट'
                : 'Unlimited AI, Ultra HD photos & priority support'}
            </p>
          </div>
          <span className="px-2.5 py-1 bg-white text-orange-600 font-extrabold text-xs rounded-xl shadow">
            Active
          </span>
        </div>
      </div>

      {/* Settings Menu Options */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-3 shadow-sm border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 text-xs font-medium">
        {/* Language */}
        <div
          onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
          className="p-3 flex items-center justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-2xl transition"
        >
          <div className="flex items-center space-x-3 text-slate-800 dark:text-slate-200">
            <Languages className="w-4 h-4 text-orange-500" />
            <span>{language === 'hi' ? 'ऐप की भाषा (Language)' : 'App Language'}</span>
          </div>
          <span className="font-bold text-orange-600">
            {language === 'hi' ? 'हिन्दी (Hindi)' : 'English'}
          </span>
        </div>

        {/* Theme mode */}
        <div
          onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
          className="p-3 flex items-center justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-2xl transition"
        >
          <div className="flex items-center space-x-3 text-slate-800 dark:text-slate-200">
            {theme === 'light' ? (
              <Moon className="w-4 h-4 text-indigo-500" />
            ) : (
              <Sun className="w-4 h-4 text-amber-500" />
            )}
            <span>{language === 'hi' ? 'डार्क / लाइट मोड' : 'Dark / Light Theme'}</span>
          </div>
          <span className="font-bold capitalize text-slate-500">{theme}</span>
        </div>

        {/* Android Native Frame Switch */}
        <div
          onClick={() => setIsAndroidFrame((prev) => !prev)}
          className="p-3 flex items-center justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-2xl transition"
        >
          <div className="flex items-center space-x-3 text-slate-800 dark:text-slate-200">
            <Smartphone className="w-4 h-4 text-green-500" />
            <span>
              {language === 'hi' ? 'एंड्रॉयड फोन फ्रेम व्यू' : 'Android Mobile Frame Simulator'}
            </span>
          </div>
          <span className="font-bold text-orange-600">
            {isAndroidFrame ? 'सक्रिय (On)' : 'निष्क्रिय (Off)'}
          </span>
        </div>

        {/* Android / Flutter Project Code Viewer & Exporter */}
        <div
          onClick={() => setIsExportModalOpen(true)}
          className="p-3 flex items-center justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-2xl transition"
        >
          <div className="flex items-center space-x-3 text-slate-800 dark:text-slate-200">
            <Code className="w-4 h-4 text-blue-500" />
            <span>
              {language === 'hi'
                ? 'एंड्रॉयड स्टूडियो / Flutter सोर्स कोड'
                : 'Android Studio / Flutter Code Exporter'}
            </span>
          </div>
          <Download className="w-4 h-4 text-slate-400" />
        </div>

        {/* Admin Panel */}
        <div
          onClick={() => setIsAdminModalOpen(true)}
          className="p-3 flex items-center justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-2xl transition"
        >
          <div className="flex items-center space-x-3 text-slate-800 dark:text-slate-200">
            <Shield className="w-4 h-4 text-red-500" />
            <span>{language === 'hi' ? 'एडमिन कंट्रोल पैनल' : 'Admin Control Dashboard'}</span>
          </div>
          <span className="text-[10px] text-slate-400">PIN: 1234</span>
        </div>
      </div>

      {/* App Version Info */}
      <div className="text-center py-3 text-slate-400 text-[11px] space-y-1">
        <p className="font-bold text-slate-600 dark:text-slate-400">
          Deepak Smart App • Version 2.5.0-PRO (Commercial)
        </p>
        <p>आपका अपना डिजिटल स्मार्ट साथी • Made for Digital Bharat</p>
        <p className="text-[10px] text-slate-500">Contact: deepakgayacsc@gmail.com</p>
      </div>

      {/* Rewarded Ad Video Modal Simulator */}
      {isAdPlaying && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-orange-500/40 rounded-3xl p-6 text-white text-center max-w-xs w-full space-y-4">
            <div className="w-12 h-12 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center mx-auto">
              <PlayCircle className="w-7 h-7 animate-spin" />
            </div>
            <h4 className="text-sm font-bold">दीपक स्मार्ट स्पॉन्सर विज्ञापन</h4>
            <p className="text-xs text-slate-400">
              सीएससी सेंटर के लिए सर्वश्रेष्ठ लेमिनेटर व पीवीसी कार्ड प्रिंटर
            </p>
            <div className="text-xl font-black text-amber-400">{adTimer}s शेष</div>
            <p className="text-[10px] text-slate-500">
              विज्ञापन समाप्त होने पर +10 AI क्रेडिट्स आपके खाते में जुड़ेंगे।
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
