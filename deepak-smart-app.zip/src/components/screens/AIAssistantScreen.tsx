import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Mic,
  MicOff,
  Image as ImageIcon,
  Copy,
  Share2,
  Trash2,
  Sparkles,
  Bot,
  User,
  Volume2,
  Check,
  FileText,
  Mail,
  Youtube,
  PenTool,
  Loader2,
  X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  image?: string;
  timestamp: string;
}

export const AIAssistantScreen: React.FC = () => {
  const { language, user, deductCredit, addCredits, setIsVipModalOpen } = useApp();
  const [activeTab, setActiveTab] = useState<'chat' | 'writer'>('chat');

  // Chat states
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-welcome',
      sender: 'ai',
      text:
        language === 'hi'
          ? 'नमस्ते दीपक जी! 🙏 मैं "दीपक एआई" (Deepak AI) हूँ—आपका अपना डिजिटल स्मार्ट साथी।\n\nआप मुझसे सरकारी योजनाओं, RTPS प्रमाण पत्र, पैन/आधार सुधार, बैंक प्रार्थना पत्र या किसी भी फॉर्म के बारे में सरल हिंदी में पूछ सकते हैं। आप कोई दस्तावेज़ या फोटो अपलोड करके भी सवाल पूछ सकते हैं!'
          : 'Hello Deepak! 🙏 I am "Deepak AI", your digital smart companion.\n\nAsk me anything about govt schemes, RTPS forms, PAN/Aadhaar updates, bank applications, or upload any document for simple explanation!',
      timestamp: 'Just now',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Writer Studio states
  const [writerType, setWriterType] = useState<
    'application' | 'letter' | 'email' | 'youtube' | 'poster'
  >('application');
  const [writerTopic, setWriterTopic] = useState('');
  const [writerRecipient, setWriterRecipient] = useState('');
  const [writerKeyPoints, setWriterKeyPoints] = useState('');
  const [generatedOutput, setGeneratedOutput] = useState('');
  const [isWriting, setIsWriting] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Voice recognition
  const toggleSpeechRecognition = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert(
        language === 'hi'
          ? 'आपके ब्राउज़र में वॉइस इनपुट उपलब्ध नहीं है।'
          : 'Voice input not supported on this browser.'
      );
      return;
    }
    try {
      const reco = new SpeechRecognition();
      reco.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
      reco.interimResults = false;
      reco.onstart = () => setIsListening(true);
      reco.onresult = (e: any) => {
        const text = e.results[0][0].transcript;
        setInputText((prev) => (prev ? `${prev} ${text}` : text));
      };
      reco.onerror = () => setIsListening(false);
      reco.onend = () => setIsListening(false);
      reco.start();
    } catch (e) {
      setIsListening(false);
    }
  };

  // Text to speech
  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const cleanText = text.replace(/[*#_~`]/g, '');
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
      utterance.rate = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSendMessage = async () => {
    if ((!inputText.trim() && !selectedImage) || isLoading) return;

    if (!deductCredit()) {
      setIsVipModalOpen(true);
      return;
    }

    const userMsg: Message = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: inputText,
      image: selectedImage || undefined,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    const currentInput = inputText;
    const currentImage = selectedImage;
    setInputText('');
    setSelectedImage(null);
    setIsLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: currentInput,
          imageBase64: currentImage,
          history: messages.slice(-4).map((m) => ({
            role: m.sender === 'user' ? 'user' : 'model',
            text: m.text,
          })),
        }),
      });

      const data = await res.json();
      const aiReply =
        data.reply ||
        (language === 'hi'
          ? 'माफ़ कीजिये, सर्वर से उत्तर नहीं मिला।'
          : 'Sorry, no response received.');

      setMessages((prev) => [
        ...prev,
        {
          id: `ai_${Date.now()}`,
          sender: 'ai',
          text: aiReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `ai_${Date.now()}`,
          sender: 'ai',
          text:
            language === 'hi'
              ? 'नेटवर्क समस्या के कारण उत्तर नहीं मिला। कृपया इंटरनेट कनेक्शन जांचें।'
              : 'Network error. Please check your connection.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const shareOnWhatsApp = (text: string) => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const handleGenerateWriter = async () => {
    if (!writerTopic.trim() || isWriting) return;
    if (!deductCredit()) {
      setIsVipModalOpen(true);
      return;
    }

    setIsWriting(true);
    setGeneratedOutput('');

    try {
      const res = await fetch('/api/ai/write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: writerType,
          topic: writerTopic,
          recipient: writerRecipient,
          language: language === 'hi' ? 'Hindi' : 'English',
          keyPoints: writerKeyPoints,
        }),
      });
      const data = await res.json();
      setGeneratedOutput(data.content || 'तैयार नहीं हो सका।');
    } catch (e: any) {
      setGeneratedOutput('त्रुटि: ' + e.message);
    } finally {
      setIsWriting(false);
    }
  };

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto select-none space-y-3">
      {/* Top AI Header */}
      <div className="bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 rounded-3xl p-4 text-white shadow-lg flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white ring-2 ring-white/30 shadow-inner">
            <Bot className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
                Deepak AI Assistant
              </h2>
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
            </div>
            <p className="text-xs text-orange-100 font-medium">
              {language === 'hi'
                ? 'सरल हिंदी में सरकारी व डिजिटल समाधान'
                : 'Simple solutions in Hindi & English'}
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            setMessages([
              {
                id: 'welcome_reset',
                sender: 'ai',
                text:
                  language === 'hi'
                    ? 'नया चैट शुरू हो गया है। बताएं मैं आपकी क्या सहायता करूँ?'
                    : 'New chat started. How can I help you today?',
                timestamp: 'Just now',
              },
            ]);
          }}
          title={language === 'hi' ? 'नया चैट' : 'New Chat'}
          className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition active:scale-95"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs Switcher: Chat vs Writer Studio */}
      <div className="flex items-center p-1 bg-slate-200/80 dark:bg-slate-800 rounded-2xl">
        <button
          onClick={() => setActiveTab('chat')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 ${
            activeTab === 'chat'
              ? 'bg-white dark:bg-slate-900 text-orange-600 dark:text-orange-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Bot className="w-3.5 h-3.5" />
          <span>{language === 'hi' ? 'स्मार्ट बातचीत (Chat)' : 'Smart Chat'}</span>
        </button>

        <button
          onClick={() => setActiveTab('writer')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 ${
            activeTab === 'writer'
              ? 'bg-white dark:bg-slate-900 text-orange-600 dark:text-orange-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <PenTool className="w-3.5 h-3.5" />
          <span>{language === 'hi' ? 'आवेदन व पत्र लेखक (Writer)' : 'AI Writer Studio'}</span>
        </button>
      </div>

      {activeTab === 'chat' ? (
        /* CHAT INTERFACE */
        <div className="flex flex-col h-[520px] bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden">
          {/* Messages list */}
          <div className="flex-1 overflow-y-auto p-3.5 space-y-3.5">
            {messages.map((m) => {
              const isAi = m.sender === 'ai';
              return (
                <div
                  key={m.id}
                  className={`flex flex-col ${isAi ? 'items-start' : 'items-end'}`}
                >
                  <div
                    className={`max-w-[88%] rounded-2xl p-3 text-xs sm:text-[13px] leading-relaxed shadow-xs ${
                      isAi
                        ? 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-sm'
                        : 'bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-tr-sm'
                    }`}
                  >
                    {/* User uploaded image preview if any */}
                    {m.image && (
                      <div className="mb-2 rounded-xl overflow-hidden border border-white/20 max-h-48">
                        <img
                          src={m.image}
                          alt="Uploaded query document"
                          className="w-full object-cover"
                        />
                      </div>
                    )}

                    <div className="whitespace-pre-wrap font-normal">{m.text}</div>

                    <div
                      className={`flex items-center justify-between mt-2 pt-1.5 border-t ${
                        isAi ? 'border-slate-200 dark:border-slate-700/60' : 'border-white/20'
                      } text-[10px] opacity-75`}
                    >
                      <span>{m.timestamp}</span>

                      {isAi && (
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => speakText(m.text)}
                            title="सुनें (Read Aloud)"
                            className="hover:text-orange-500 transition"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => copyToClipboard(m.text, m.id)}
                            title="कॉपी करें"
                            className="hover:text-orange-500 transition"
                          >
                            {copiedId === m.id ? (
                              <Check className="w-3.5 h-3.5 text-green-500" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <button
                            onClick={() => shareOnWhatsApp(m.text)}
                            title="व्हाट्सएप पर भेजें"
                            className="hover:text-green-500 transition"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}

            {isLoading && (
              <div className="flex items-center space-x-2 p-3 bg-slate-100 dark:bg-slate-800 rounded-2xl max-w-[70%] text-xs text-orange-600 dark:text-orange-400">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="font-semibold">
                  {language === 'hi' ? 'दीपक AI सोच रहा है...' : 'Deepak AI is thinking...'}
                </span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick preset chips */}
          <div className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center space-x-1.5 overflow-x-auto no-scrollbar">
            <button
              onClick={() => setInputText('आय प्रमाण पत्र बनवाने में कितना दिन और क्या कागज़ लगता है?')}
              className="text-[10px] font-medium px-2.5 py-1 rounded-full bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 shrink-0 hover:bg-orange-50"
            >
              📄 आय प्रमाण पत्र नियम
            </button>
            <button
              onClick={() => setInputText('बैंक पासबुक खो जाने पर शाखा प्रबंधक को आवेदन पत्र लिखो')}
              className="text-[10px] font-medium px-2.5 py-1 rounded-full bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 shrink-0 hover:bg-orange-50"
            >
              🏦 बैंक पासबुक आवेदन
            </button>
            <button
              onClick={() => setInputText('राशन कार्ड में नया सदस्य (बच्चा या बहू) कैसे जोड़े?')}
              className="text-[10px] font-medium px-2.5 py-1 rounded-full bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 shrink-0 hover:bg-orange-50"
            >
              🍚 राशन कार्ड नाम जोड़ना
            </button>
          </div>

          {/* Image preview before send */}
          {selectedImage && (
            <div className="px-3 pt-2 pb-1 bg-slate-50 dark:bg-slate-800 flex items-center justify-between border-t border-slate-200 dark:border-slate-700">
              <div className="flex items-center space-x-2">
                <img
                  src={selectedImage}
                  alt="Thumbnail"
                  className="w-10 h-10 object-cover rounded-lg border border-orange-500"
                />
                <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                  {language === 'hi' ? 'दस्तावेज़/फोटो संलग्न' : 'Image attached'}
                </span>
              </div>
              <button
                onClick={() => setSelectedImage(null)}
                className="p-1 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Input Box */}
          <div className="p-2.5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center space-x-1.5">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleImageUpload}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              title="दस्तावेज़ या फोटो अपलोड करें"
              className="p-2 text-slate-500 hover:text-orange-500 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              <ImageIcon className="w-5 h-5" />
            </button>

            <button
              onClick={toggleSpeechRecognition}
              title="बोलकर टाइप करें"
              className={`p-2 rounded-xl transition ${
                isListening
                  ? 'bg-red-500 text-white animate-pulse'
                  : 'text-slate-500 hover:text-orange-500 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder={
                language === 'hi'
                  ? 'पूछें... (जैसे: बैंक खाता ट्रांसफर पत्र लिखें)'
                  : 'Ask Deepak AI anything...'
              }
              className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
            />

            <button
              onClick={handleSendMessage}
              disabled={isLoading || (!inputText.trim() && !selectedImage)}
              className="p-2.5 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white rounded-2xl shadow-sm transition active:scale-95"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* AI WRITER STUDIO INTERFACE */
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center space-x-1.5">
              <Sparkles className="w-4 h-4 text-orange-500" />
              <span>
                {language === 'hi'
                  ? 'आधिकारिक प्रार्थना पत्र व सामग्री जनरेटर'
                  : 'Official Application & Content Writer'}
              </span>
            </h3>
            <p className="text-[11px] text-slate-500">
              {language === 'hi'
                ? 'सरकारी दफ्तर, बैंक, स्कूल, ईमेल या सोशल मीडिया के लिए तैयार ड्राफ्ट बनाएं।'
                : 'Instantly generate official letters, applications, emails & YouTube copy.'}
            </p>
          </div>

          {/* Type selector */}
          <div className="grid grid-cols-3 gap-1.5 text-center">
            {[
              { id: 'application', labelHi: 'बैंक/सरकारी आवेदन', labelEn: 'Application' },
              { id: 'letter', labelHi: 'औपचारिक पत्र', labelEn: 'Letter' },
              { id: 'email', labelHi: 'ईमेल ड्राफ्ट', labelEn: 'Email' },
              { id: 'youtube', labelHi: 'यूट्यूब टाइटल/टैग्स', labelEn: 'YouTube' },
              { id: 'poster', labelHi: 'पोस्टर स्लोगन', labelEn: 'Poster/Banner' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setWriterType(t.id as any)}
                className={`py-1.5 px-2 rounded-xl text-[11px] font-bold border transition ${
                  writerType === t.id
                    ? 'bg-orange-500 text-white border-orange-500 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                {language === 'hi' ? t.labelHi : t.labelEn}
              </button>
            ))}
          </div>

          {/* Form fields */}
          <div className="space-y-2.5">
            <div>
              <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1">
                {language === 'hi' ? 'विषय (Subject / Topic):' : 'Subject / Topic:'}
              </label>
              <input
                type="text"
                value={writerTopic}
                onChange={(e) => setWriterTopic(e.target.value)}
                placeholder={
                  writerType === 'application'
                    ? 'जैसे: बैंक में नया मोबाइल नंबर जोड़ने हेतु'
                    : 'जैसे: साइबर कैफे होली डिस्काउंट ऑफर'
                }
                className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white px-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1">
                {language === 'hi' ? 'अधिकारी या प्राप्तकर्ता (Recipient):' : 'Recipient / Officer:'}
              </label>
              <input
                type="text"
                value={writerRecipient}
                onChange={(e) => setWriterRecipient(e.target.value)}
                placeholder="जैसे: श्रीमान शाखा प्रबंधक महोदय, भारतीय स्टेट बैंक"
                className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white px-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1">
                {language === 'hi' ? 'खास बातें या विवरण (Key details):' : 'Key details / account number:'}
              </label>
              <textarea
                rows={2}
                value={writerKeyPoints}
                onChange={(e) => setWriterKeyPoints(e.target.value)}
                placeholder="जैसे: पुराना नंबर बंद हो गया है, नया नंबर 9876543210 जोड़ना है, खाता सं. 123456"
                className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white px-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-orange-500"
              ></textarea>
            </div>

            <button
              onClick={handleGenerateWriter}
              disabled={isWriting || !writerTopic.trim()}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 text-white text-xs font-bold shadow-md hover:from-orange-600 hover:to-amber-600 transition flex items-center justify-center space-x-1.5 disabled:opacity-50"
            >
              {isWriting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{language === 'hi' ? 'ड्राफ्ट तैयार हो रहा है...' : 'Generating draft...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{language === 'hi' ? 'AI ड्राफ्ट तैयार करें' : 'Generate AI Draft'}</span>
                </>
              )}
            </button>
          </div>

          {/* Generated Result Output */}
          {generatedOutput && (
            <div className="mt-4 p-3.5 bg-slate-50 dark:bg-slate-800/90 rounded-2xl border border-orange-200 dark:border-slate-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider">
                  {language === 'hi' ? 'तैयार आधिकारिक प्रारूप' : 'Generated Document'}
                </span>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => speakText(generatedOutput)}
                    className="p-1 text-slate-500 hover:text-orange-500"
                    title="बोलकर सुनें"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => copyToClipboard(generatedOutput, 'writer_copy')}
                    className="p-1 text-slate-500 hover:text-orange-500"
                    title="कॉपी करें"
                  >
                    {copiedId === 'writer_copy' ? (
                      <Check className="w-4 h-4 text-green-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                  <button
                    onClick={() => shareOnWhatsApp(generatedOutput)}
                    className="p-1 text-slate-500 hover:text-green-500"
                    title="व्हाट्सएप शेयर"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-xs text-slate-800 dark:text-slate-100 whitespace-pre-wrap leading-relaxed max-h-64 overflow-y-auto font-sans">
                {generatedOutput}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
