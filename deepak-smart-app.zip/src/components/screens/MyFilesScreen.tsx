import React, { useState } from 'react';
import {
  FolderCheck,
  Search,
  FileText,
  Image as ImageIcon,
  Download,
  Trash2,
  Calendar,
  HardDrive,
  Share2,
  CheckCircle,
  FileSpreadsheet,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const MyFilesScreen: React.FC = () => {
  const { language, savedFiles, deleteFile } = useApp();
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [shareSuccess, setShareSuccess] = useState(false);

  const filtered = savedFiles.filter((file) => {
    const matchesSearch = file.title.toLowerCase().includes(search.toLowerCase());
    const matchesType = filterType === 'all' || file.type === filterType;
    return matchesSearch && matchesType;
  });

  const handleShare = (file: typeof savedFiles[0]) => {
    const shareText = `Deepak Smart App Generated File: ${file.title} (${file.size})`;
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank');
    setShareSuccess(true);
    setTimeout(() => setShareSuccess(false), 2000);
  };

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto select-none space-y-3.5">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 rounded-3xl p-4 text-white shadow-lg flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white ring-2 ring-white/30 shadow-inner">
            <FolderCheck className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
              My Files & Storage
            </h2>
            <p className="text-xs text-orange-100 font-medium">
              {language === 'hi'
                ? 'सुरक्षित डिजिटल डॉक्युमेंट लॉकर'
                : 'Secure digital document locker'}
            </p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-[10px] text-white/80 block">कुल फाइलें</span>
          <span className="text-base font-black text-white">{savedFiles.length}</span>
        </div>
      </div>

      {/* Storage info pill */}
      <div className="p-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
        <div className="flex items-center space-x-2">
          <HardDrive className="w-4 h-4 text-orange-500" />
          <span>लोकल ऑफलाइन स्टोरेज: सक्रिय (Offline Safe)</span>
        </div>
        <span className="text-green-600 font-bold text-[10px]">100% Private</span>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={language === 'hi' ? 'फाइल नाम खोजें...' : 'Search saved files...'}
          className="w-full bg-white dark:bg-slate-900 text-slate-900 dark:text-white pl-10 pr-4 py-2.5 rounded-2xl text-xs border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-orange-500"
        />
      </div>

      {/* Filters */}
      <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar">
        {[
          { id: 'all', label: 'सभी (All)' },
          { id: 'pdf', label: 'PDF डॉक्स' },
          { id: 'image', label: 'फोटो व पासपोर्ट' },
          { id: 'invoice', label: 'बिल व इनवॉइस' },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilterType(f.id)}
            className={`py-1.5 px-3 rounded-xl text-[11px] font-bold shrink-0 transition ${
              filterType === f.id
                ? 'bg-orange-500 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Files List */}
      <div className="space-y-2.5">
        {filtered.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 text-center text-xs text-slate-400">
            {language === 'hi' ? 'कोई फाइल नहीं मिली।' : 'No files found.'}
          </div>
        ) : (
          filtered.map((file) => (
            <div
              key={file.id}
              className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between hover:shadow-sm transition"
            >
              <div className="flex items-center space-x-3">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    file.type === 'pdf'
                      ? 'bg-red-100 text-red-600'
                      : file.type === 'invoice'
                      ? 'bg-indigo-100 text-indigo-600'
                      : 'bg-orange-100 text-orange-600'
                  }`}
                >
                  {file.type === 'pdf' ? (
                    <FileText className="w-5 h-5" />
                  ) : file.type === 'invoice' ? (
                    <FileSpreadsheet className="w-5 h-5" />
                  ) : (
                    <ImageIcon className="w-5 h-5" />
                  )}
                </div>

                <div className="space-y-0.5">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1 max-w-[180px]">
                    {file.title}
                  </h4>
                  <p className="text-[10px] text-slate-400">
                    {file.category} • {file.size} • {file.date}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-1">
                <button
                  onClick={() => handleShare(file)}
                  className="p-1.5 text-slate-400 hover:text-green-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                  title="WhatsApp पर भेजें"
                >
                  <Share2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => deleteFile(file.id)}
                  className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                  title="हटाएं"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {shareSuccess && (
        <div className="p-2 rounded-xl bg-green-50 text-green-700 text-xs font-semibold flex items-center justify-center space-x-1.5 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-green-600" />
          <span>WhatsApp लिंक तैयार!</span>
        </div>
      )}
    </div>
  );
};
