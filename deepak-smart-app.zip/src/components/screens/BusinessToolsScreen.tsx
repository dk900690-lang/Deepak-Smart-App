import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck,
  FileSpreadsheet,
  QrCode,
  CreditCard,
  Download,
  Plus,
  Trash2,
  Printer,
  Share2,
  CheckCircle,
  Calculator,
  IndianRupee,
  Building2,
  Phone,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CSC_RATES_DEFAULT } from '../../data/mockData';
import { jsPDF } from 'jspdf';
import QRCode from 'qrcode';

interface InvoiceRow {
  desc: string;
  qty: number;
  rate: number;
}

interface KhataEntry {
  id: string;
  name: string;
  amount: number;
  type: 'in' | 'out'; // in = Jama, out = Udhar/Kharch
  note: string;
  date: string;
}

export const BusinessToolsScreen: React.FC = () => {
  const { language, user, saveFile } = useApp();

  const [activeTab, setActiveTab] = useState<
    'invoice' | 'upi-qr' | 'visiting-card' | 'khata' | 'calculator'
  >('invoice');

  // Invoice States
  const [customerName, setCustomerName] = useState('रोहित कुमार (Rohit Kumar)');
  const [customerPhone, setCustomerPhone] = useState('9876543210');
  const [invoiceNumber, setInvoiceNumber] = useState('INV-2026-108');
  const [items, setItems] = useState<InvoiceRow[]>([
    { desc: 'Passport Photo 8-on-1 Print', qty: 2, rate: 40 },
    { desc: 'A4 Color Document Print & Lamination', qty: 3, rate: 30 },
    { desc: 'Online Form Submission Fee', qty: 1, rate: 50 },
  ]);

  // UPI QR States
  const [upiVpa, setUpiVpa] = useState(user.upiId || 'deepakgayacsc@okaxis');
  const [payeeName, setPayeeName] = useState(user.shopName || 'Deepak Smart Seva');
  const [upiAmount, setUpiAmount] = useState('100');
  const [qrDataUrl, setQrDataUrl] = useState('');

  // Visiting Card States
  const [cardShopName, setCardShopName] = useState(user.shopName || 'Deepak Digital CSC Seva Kendra');
  const [cardOwner, setCardOwner] = useState(user.name || 'Deepak Kumar');
  const [cardPhone, setCardPhone] = useState(user.phone || '+91 98765 43210');
  const [cardAddress, setCardAddress] = useState('Near Block Road, Gaya, Bihar - 823001');

  // Khata / Cashbook States
  const [khataList, setKhataList] = useState<KhataEntry[]>([
    { id: '1', name: 'अमित कुमार (फोटो प्रिंट)', amount: 120, type: 'in', note: 'कैश प्राप्त', date: 'आज' },
    { id: '2', name: 'सुनील शर्मा (ऑनलाइन फॉर्म)', amount: 70, type: 'out', note: 'उधार (Pending)', date: 'कल' },
  ]);
  const [khataName, setKhataName] = useState('');
  const [khataAmount, setKhataAmount] = useState('');
  const [khataType, setKhataType] = useState<'in' | 'out'>('in');
  const [khataNote, setKhataNote] = useState('');

  // Calculator States
  const [quantities, setQuantities] = useState<Record<number, number>>({
    0: 5, // A4 xerox
    3: 1, // Passport photo
    4: 2, // Lamination
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Generate UPI QR code
  useEffect(() => {
    generateUpiQr();
  }, [upiVpa, payeeName, upiAmount]);

  const generateUpiQr = async () => {
    try {
      const upiUrl = `upi://pay?pa=${encodeURIComponent(upiVpa)}&pn=${encodeURIComponent(
        payeeName
      )}&am=${encodeURIComponent(upiAmount || '0')}&cu=INR`;
      const url = await QRCode.toDataURL(upiUrl, {
        width: 320,
        margin: 2,
        color: {
          dark: '#102A43',
          light: '#FFFFFF',
        },
      });
      setQrDataUrl(url);
    } catch (err) {
      console.error(err);
    }
  };

  // Invoice calculations
  const subTotal = items.reduce((acc, row) => acc + row.qty * row.rate, 0);
  const gst = Math.round(subTotal * 0.18);
  const grandTotal = subTotal + gst;

  const handleAddItem = () => {
    setItems([...items, { desc: 'नया सेवा आइटम (New Service)', qty: 1, rate: 20 }]);
  };

  const handleDownloadInvoice = () => {
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    // Brand Header
    pdf.setFillColor(16, 42, 67);
    pdf.rect(0, 0, 210, 32, 'F');

    pdf.setFontSize(18);
    pdf.setTextColor(255, 140, 0);
    pdf.text(user.shopName || 'Deepak Digital CSC Seva Kendra', 15, 15);

    pdf.setFontSize(9);
    pdf.setTextColor(255, 255, 255);
    pdf.text('Official GST/Tax Invoice & Customer Cash Memo', 15, 22);
    pdf.text(`Phone: ${user.phone} • Email: ${user.email}`, 15, 27);

    // Invoice Meta
    pdf.setTextColor(50, 50, 50);
    pdf.setFontSize(10);
    pdf.text(`Invoice No: ${invoiceNumber}`, 15, 42);
    pdf.text(`Date: ${new Date().toLocaleDateString()}`, 15, 48);
    pdf.text(`Billed To: ${customerName}`, 130, 42);
    pdf.text(`Phone: ${customerPhone}`, 130, 48);

    // Items table header
    pdf.setFillColor(240, 240, 240);
    pdf.rect(15, 55, 180, 8, 'F');
    pdf.setFontSize(9);
    pdf.setTextColor(0, 0, 0);
    pdf.text('Item Description', 18, 60);
    pdf.text('Qty', 120, 60);
    pdf.text('Rate', 145, 60);
    pdf.text('Amount (INR)', 170, 60);

    let startY = 68;
    items.forEach((item) => {
      pdf.text(item.desc, 18, startY);
      pdf.text(String(item.qty), 122, startY);
      pdf.text(`Rs. ${item.rate}`, 145, startY);
      pdf.text(`Rs. ${item.qty * item.rate}`, 170, startY);
      startY += 8;
    });

    pdf.line(15, startY, 195, startY);
    startY += 8;

    pdf.setFontSize(10);
    pdf.text(`Subtotal: Rs. ${subTotal}`, 145, startY);
    startY += 6;
    pdf.text(`GST (18%): Rs. ${gst}`, 145, startY);
    startY += 8;

    pdf.setFontSize(12);
    pdf.setTextColor(255, 140, 0);
    pdf.text(`Grand Total: Rs. ${grandTotal}`, 135, startY);

    // Footer
    pdf.setFontSize(9);
    pdf.setTextColor(120, 120, 120);
    pdf.text('Thank you for your business! Powered by Deepak Smart App.', 15, 280);

    const fileName = `Invoice_${invoiceNumber}.pdf`;
    pdf.save(fileName);

    saveFile({
      title: fileName,
      type: 'invoice',
      size: '62 KB',
      dataUrl: '',
      category: 'Business Billing',
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleAddKhata = () => {
    if (!khataName.trim() || !khataAmount) return;
    const newEntry: KhataEntry = {
      id: `kh_${Date.now()}`,
      name: khataName,
      amount: Number(khataAmount),
      type: khataType,
      note: khataNote || (khataType === 'in' ? 'जमा (Received)' : 'उधार (Credit)'),
      date: 'आज',
    };
    setKhataList([newEntry, ...khataList]);
    setKhataName('');
    setKhataAmount('');
    setKhataNote('');
  };

  const totalJama = khataList
    .filter((k) => k.type === 'in')
    .reduce((acc, k) => acc + k.amount, 0);
  const totalUdhar = khataList
    .filter((k) => k.type === 'out')
    .reduce((acc, k) => acc + k.amount, 0);

  // Total rate calculator
  const calcTotal = CSC_RATES_DEFAULT.reduce((acc, item, idx) => {
    const qty = quantities[idx] || 0;
    return acc + qty * item.rate;
  }, 0);

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto select-none space-y-3.5">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 via-violet-600 to-indigo-700 rounded-3xl p-4 text-white shadow-lg flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white ring-2 ring-white/30 shadow-inner">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
              Smart Business Tools
            </h2>
            <p className="text-xs text-indigo-100 font-medium">
              {language === 'hi'
                ? 'GST बिल, UPI QR, विजिटिंग कार्ड, खाता'
                : 'Invoices, UPI QR, cards & cashbook'}
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-5 gap-1 bg-slate-200/80 dark:bg-slate-800 p-1 rounded-2xl text-[10px] font-bold">
        {[
          { id: 'invoice', labelHi: 'बिल/इनवॉइस', labelEn: 'Invoice' },
          { id: 'upi-qr', labelHi: 'UPI QR', labelEn: 'UPI QR' },
          { id: 'visiting-card', labelHi: 'कार्ड मेकर', labelEn: 'Card' },
          { id: 'khata', labelHi: 'खाता बही', labelEn: 'Khata' },
          { id: 'calculator', labelHi: 'कैलकुलेटर', labelEn: 'Calc' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`py-1.5 rounded-xl text-center transition ${
              activeTab === t.id
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            {language === 'hi' ? t.labelHi : t.labelEn}
          </button>
        ))}
      </div>

      {/* TAB 1: Invoice Generator */}
      {activeTab === 'invoice' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3.5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                {language === 'hi' ? 'GST व कैश मेमो इनवॉइस' : 'GST / Cash Invoice Generator'}
              </h3>
              <p className="text-[10px] text-slate-500">
                {user.shopName}
              </p>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600">
              {invoiceNumber}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <label className="text-[10px] font-bold text-slate-500 block mb-0.5">ग्राहक का नाम (Customer):</label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white px-2.5 py-1.5 rounded-xl text-xs border border-slate-200 dark:border-slate-700"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-500 block mb-0.5">मोबाइल नंबर:</label>
              <input
                type="text"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white px-2.5 py-1.5 rounded-xl text-xs border border-slate-200 dark:border-slate-700"
              />
            </div>
          </div>

          {/* Itemized Table */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
              सामान / सेवा सूची (Items):
            </span>
            {items.map((row, idx) => (
              <div key={idx} className="flex items-center space-x-1.5">
                <input
                  type="text"
                  value={row.desc}
                  onChange={(e) => {
                    const updated = [...items];
                    updated[idx].desc = e.target.value;
                    setItems(updated);
                  }}
                  className="flex-1 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white px-2 py-1 rounded-xl text-[11px] border border-slate-200 dark:border-slate-700"
                />
                <input
                  type="number"
                  value={row.qty}
                  onChange={(e) => {
                    const updated = [...items];
                    updated[idx].qty = Number(e.target.value);
                    setItems(updated);
                  }}
                  className="w-12 text-center bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white px-1 py-1 rounded-xl text-[11px] border border-slate-200 dark:border-slate-700"
                />
                <input
                  type="number"
                  value={row.rate}
                  onChange={(e) => {
                    const updated = [...items];
                    updated[idx].rate = Number(e.target.value);
                    setItems(updated);
                  }}
                  className="w-14 text-center bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white px-1 py-1 rounded-xl text-[11px] border border-slate-200 dark:border-slate-700"
                />
                <button
                  onClick={() => setItems(items.filter((_, i) => i !== idx))}
                  className="p-1 text-slate-400 hover:text-red-500"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}

            <button
              onClick={handleAddItem}
              className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 flex items-center space-x-1 hover:underline pt-1"
            >
              <Plus className="w-3 h-3" />
              <span>+ और सेवा जोड़ें (Add Item)</span>
            </button>
          </div>

          {/* Totals */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl text-xs space-y-1">
            <div className="flex justify-between text-slate-600 dark:text-slate-300">
              <span>उप-कुल (Subtotal):</span>
              <span className="font-semibold">₹{subTotal}</span>
            </div>
            <div className="flex justify-between text-slate-600 dark:text-slate-300">
              <span>GST (18%):</span>
              <span className="font-semibold">₹{gst}</span>
            </div>
            <div className="flex justify-between text-sm font-extrabold text-indigo-600 dark:text-indigo-400 pt-1 border-t border-slate-200 dark:border-slate-700">
              <span>कुल देय राशि (Grand Total):</span>
              <span>₹{grandTotal}</span>
            </div>
          </div>

          {/* Action */}
          <button
            onClick={handleDownloadInvoice}
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition flex items-center justify-center space-x-1.5 active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>{language === 'hi' ? 'PDF इनवॉइस डाउनलोड करें' : 'Download Invoice PDF'}</span>
          </button>
        </div>
      )}

      {/* TAB 2: Business UPI QR Code Generator */}
      {activeTab === 'upi-qr' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3.5 text-center">
          <div>
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {language === 'hi' ? 'दुकान काउंटर UPI पेमेंट QR' : 'Shop Counter UPI QR Generator'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {language === 'hi'
                ? 'Google Pay, PhonePe, Paytm, BHIM किसी भी ऐप से सीधे बैंक में पेमेंट लें।'
                : 'Accept payments from any UPI app directly into your bank.'}
            </p>
          </div>

          {/* Rendered Scannable QR Card */}
          <div className="p-4 bg-gradient-to-b from-indigo-50 to-white dark:from-slate-800 dark:to-slate-900 rounded-3xl border border-indigo-100 dark:border-slate-700 max-w-xs mx-auto shadow-md">
            <div className="flex items-center justify-center space-x-1.5 mb-2">
              <span className="font-extrabold text-sm text-[#102A43] dark:text-white">BHARAT</span>
              <span className="px-1.5 py-0.2 bg-orange-500 text-white font-bold text-[9px] rounded">
                UPI
              </span>
            </div>

            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">{payeeName}</h4>
            <p className="text-[10px] text-slate-500">{upiVpa}</p>

            {qrDataUrl && (
              <div className="my-3 flex justify-center">
                <img
                  src={qrDataUrl}
                  alt="Scannable UPI QR"
                  className="w-48 h-48 rounded-xl shadow border border-slate-200 dark:border-slate-700 p-1 bg-white"
                />
              </div>
            )}

            <div className="text-xs font-black text-indigo-700 dark:text-indigo-400 bg-indigo-50 dark:bg-slate-800 py-1 rounded-xl">
              राशि: ₹{upiAmount || 'Any'}
            </div>
          </div>

          {/* Form settings */}
          <div className="space-y-2 text-left text-xs">
            <div>
              <label className="text-[10px] font-bold text-slate-500 block mb-0.5">UPI ID (VPA):</label>
              <input
                type="text"
                value={upiVpa}
                onChange={(e) => setUpiVpa(e.target.value)}
                placeholder="deepakgayacsc@okaxis"
                className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white p-2 rounded-xl text-xs border border-slate-200 dark:border-slate-700"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-500 block mb-0.5">राशि (Amount - Optional):</label>
              <input
                type="number"
                value={upiAmount}
                onChange={(e) => setUpiAmount(e.target.value)}
                placeholder="100"
                className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white p-2 rounded-xl text-xs border border-slate-200 dark:border-slate-700"
              />
            </div>
          </div>

          <a
            href={qrDataUrl}
            download={`UPI_QR_${payeeName}.png`}
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition flex items-center justify-center space-x-1.5"
          >
            <Download className="w-4 h-4" />
            <span>{language === 'hi' ? 'दुकान के लिए QR डाउनलोड करें' : 'Download QR Standee'}</span>
          </a>
        </div>
      )}

      {/* TAB 3: Visiting Card Maker */}
      {activeTab === 'visiting-card' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3.5">
          <div>
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {language === 'hi' ? 'डिजिटल विजिटिंग कार्ड मेकर' : 'Digital Visiting Card Maker'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {language === 'hi' ? 'अपनी दुकान का कार्ड तैयार करें और शेयर करें।' : 'Design & download visiting card.'}
            </p>
          </div>

          {/* Card Preview */}
          <div className="p-4 bg-gradient-to-r from-[#102A43] via-[#1A365D] to-[#0A192F] text-white rounded-2xl shadow-xl border border-orange-500/30 relative overflow-hidden space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-orange-500 flex items-center justify-center font-black text-white text-sm">
                  D
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-amber-400">{cardShopName}</h4>
                  <p className="text-[10px] text-slate-300">Authorized Digital Seva Kendra</p>
                </div>
              </div>
            </div>

            <div className="space-y-1 text-xs pt-1">
              <p className="font-bold text-white text-sm">{cardOwner}</p>
              <p className="text-[11px] text-orange-200 flex items-center space-x-1">
                <Phone className="w-3 h-3" />
                <span>{cardPhone}</span>
              </p>
              <p className="text-[10px] text-slate-300">{cardAddress}</p>
            </div>

            <div className="pt-2 border-t border-white/10 flex justify-between items-center text-[9px] text-orange-300">
              <span>Aadhaar • PAN • Xerox • Photo • Govt Jobs</span>
              <span>Deepak Smart App</span>
            </div>
          </div>

          {/* Inputs */}
          <div className="space-y-2 text-xs">
            <div>
              <label className="text-[10px] font-bold text-slate-500 block mb-0.5">दुकान / सेंटर का नाम:</label>
              <input
                type="text"
                value={cardShopName}
                onChange={(e) => setCardShopName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white p-2 rounded-xl text-xs border border-slate-200"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-500 block mb-0.5">संचालक का नाम (Owner):</label>
              <input
                type="text"
                value={cardOwner}
                onChange={(e) => setCardOwner(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white p-2 rounded-xl text-xs border border-slate-200"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-500 block mb-0.5">पता (Address):</label>
              <input
                type="text"
                value={cardAddress}
                onChange={(e) => setCardAddress(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white p-2 rounded-xl text-xs border border-slate-200"
              />
            </div>
          </div>

          <button
            onClick={() => {
              const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: [85, 55] });
              pdf.setFillColor(16, 42, 67);
              pdf.rect(0, 0, 85, 55, 'F');
              pdf.setTextColor(255, 140, 0);
              pdf.setFontSize(10);
              pdf.text(cardShopName, 5, 10);
              pdf.setTextColor(255, 255, 255);
              pdf.setFontSize(8);
              pdf.text(cardOwner, 5, 20);
              pdf.text(`Ph: ${cardPhone}`, 5, 26);
              pdf.setFontSize(6);
              pdf.text(cardAddress, 5, 34);
              pdf.save('Visiting_Card.pdf');
              setSavedSuccess(true);
              setTimeout(() => setSavedSuccess(false), 2000);
            }}
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow transition flex items-center justify-center space-x-1.5"
          >
            <Download className="w-4 h-4" />
            <span>{language === 'hi' ? 'विजिटिंग कार्ड PDF डाउनलोड करें' : 'Download Card PDF'}</span>
          </button>
        </div>
      )}

      {/* TAB 4: Daily Khata Cashbook */}
      {activeTab === 'khata' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {language === 'hi' ? 'दैनिक खाता (जमा व उधार हिसाब)' : 'Daily Cashbook & Ledger'}
            </h3>
            <span className="text-[10px] text-slate-400">Total Entries: {khataList.length}</span>
          </div>

          {/* Balance Cards */}
          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="p-3 rounded-2xl bg-green-50 dark:bg-green-950/40 border border-green-200 dark:border-green-800">
              <span className="text-[10px] font-bold text-green-700 dark:text-green-300">कुल जमा (Received)</span>
              <p className="text-lg font-black text-green-600">₹{totalJama}</p>
            </div>
            <div className="p-3 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800">
              <span className="text-[10px] font-bold text-red-700 dark:text-red-300">कुल उधार (Due)</span>
              <p className="text-lg font-black text-red-600">₹{totalUdhar}</p>
            </div>
          </div>

          {/* Add New Entry */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl space-y-2 border border-slate-200 dark:border-slate-700">
            <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300 block">नई एंट्री जोड़ें:</span>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="ग्राहक का नाम"
                value={khataName}
                onChange={(e) => setKhataName(e.target.value)}
                className="bg-white dark:bg-slate-900 p-2 rounded-xl text-xs border border-slate-200"
              />
              <input
                type="number"
                placeholder="रकम (₹)"
                value={khataAmount}
                onChange={(e) => setKhataAmount(e.target.value)}
                className="bg-white dark:bg-slate-900 p-2 rounded-xl text-xs border border-slate-200"
              />
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setKhataType('in')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-bold ${
                  khataType === 'in' ? 'bg-green-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700'
                }`}
              >
                जमा (Payment In)
              </button>
              <button
                onClick={() => setKhataType('out')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-bold ${
                  khataType === 'out' ? 'bg-red-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700'
                }`}
              >
                उधार (Credit Out)
              </button>
            </div>
            <button
              onClick={handleAddKhata}
              className="w-full py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow hover:bg-indigo-700 transition"
            >
              खाते में दर्ज करें
            </button>
          </div>

          {/* Entry list */}
          <div className="space-y-1.5 max-h-48 overflow-y-auto">
            {khataList.map((entry) => (
              <div
                key={entry.id}
                className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs"
              >
                <div>
                  <h5 className="font-bold text-slate-900 dark:text-white">{entry.name}</h5>
                  <span className="text-[10px] text-slate-400">{entry.note}</span>
                </div>
                <div className="text-right">
                  <span
                    className={`font-black text-sm ${
                      entry.type === 'in' ? 'text-green-600' : 'text-red-500'
                    }`}
                  >
                    {entry.type === 'in' ? `+₹${entry.amount}` : `-₹${entry.amount}`}
                  </span>
                  <span className="text-[9px] text-slate-400 block">{entry.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: CSC Service Rate Calculator */}
      {activeTab === 'calculator' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                {language === 'hi' ? 'सीएससी सर्विस रेट कैलकुलेटर' : 'CSC Rate & Billing Calculator'}
              </h3>
              <p className="text-[11px] text-slate-500">
                प्रिंट, फोटो और फॉर्म का तुरंत कुल बिल निकालें।
              </p>
            </div>
            <Calculator className="w-5 h-5 text-indigo-500" />
          </div>

          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {CSC_RATES_DEFAULT.map((item, idx) => (
              <div
                key={idx}
                className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-medium text-slate-800 dark:text-slate-200 block">
                    {item.item}
                  </span>
                  <span className="text-[10px] text-indigo-600 font-bold">₹{item.rate} / प्रति कॉपी</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <button
                    onClick={() =>
                      setQuantities({ ...quantities, [idx]: Math.max(0, (quantities[idx] || 0) - 1) })
                    }
                    className="w-6 h-6 rounded-lg bg-slate-200 dark:bg-slate-700 font-bold flex items-center justify-center text-slate-700"
                  >
                    -
                  </button>
                  <span className="w-7 text-center font-bold text-slate-900 dark:text-white">
                    {quantities[idx] || 0}
                  </span>
                  <button
                    onClick={() =>
                      setQuantities({ ...quantities, [idx]: (quantities[idx] || 0) + 1 })
                    }
                    className="w-6 h-6 rounded-lg bg-indigo-500 text-white font-bold flex items-center justify-center"
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-indigo-50 dark:bg-slate-800/80 rounded-2xl flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              कुल बिल (Total Bill):
            </span>
            <span className="text-xl font-black text-indigo-600 dark:text-indigo-400">
              ₹{calcTotal}
            </span>
          </div>
        </div>
      )}

      {savedSuccess && (
        <div className="p-2 rounded-xl bg-green-50 text-green-700 text-xs font-semibold flex items-center justify-center space-x-1.5 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-green-600" />
          <span>सफलतापूर्वक डाउनलोड और सेव हो गया!</span>
        </div>
      )}
    </div>
  );
};
