import React, { useState, useEffect } from 'react';
import {
  Briefcase,
  GraduationCap,
  Bookmark,
  ExternalLink,
  Calendar,
  Award,
  CheckCircle,
  XCircle,
  RotateCcw,
  Sparkles,
  HelpCircle,
  Clock,
  Share2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MOCK_QUIZ_QUESTIONS } from '../../data/mockData';
import { JobItem } from '../../types';

export const JobsEducationScreen: React.FC = () => {
  const { language, jobsList, bookmarkedJobs, toggleBookmarkJob } = useApp();

  const [activeTab, setActiveTab] = useState<'jobs' | 'quiz' | 'current-affairs'>('jobs');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'bihar' | 'central' | 'saved'>('all');

  // Quiz States
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [isQuizFinished, setIsQuizFinished] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);

  const filteredJobs = jobsList.filter((job) => {
    if (selectedFilter === 'saved') return bookmarkedJobs.includes(job.id);
    if (selectedFilter === 'bihar') return job.category.includes('Bihar');
    if (selectedFilter === 'central') return job.category.includes('Central');
    return true;
  });

  const handleSelectOption = (idx: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(idx);
    setShowExplanation(true);
    if (idx === MOCK_QUIZ_QUESTIONS[currentQIndex].correctIndex) {
      setQuizScore((prev) => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQIndex < MOCK_QUIZ_QUESTIONS.length - 1) {
      setCurrentQIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      setIsQuizFinished(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQIndex(0);
    setSelectedAnswer(null);
    setQuizScore(0);
    setIsQuizFinished(false);
    setShowExplanation(false);
  };

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto select-none space-y-3.5">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 rounded-3xl p-4 text-white shadow-lg flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white ring-2 ring-white/30 shadow-inner">
            <Briefcase className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
              Govt Jobs & Education
            </h2>
            <p className="text-xs text-emerald-100 font-medium">
              {language === 'hi'
                ? 'सरकारी भर्ती, एडमिट कार्ड, ऑनलाइन मॉक टेस्ट'
                : 'Sarkari vacancy, admit cards & mock quiz'}
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-3 gap-1.5 bg-slate-200/80 dark:bg-slate-800 p-1 rounded-2xl text-[11px] font-bold">
        {[
          { id: 'jobs', labelHi: 'सरकारी नौकरियां', labelEn: 'Latest Jobs' },
          { id: 'quiz', labelHi: 'ऑनलाइन टेस्ट', labelEn: 'Mock Test' },
          { id: 'current-affairs', labelHi: 'करेंट अफेयर्स', labelEn: 'Notes & GK' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`py-2 rounded-xl text-center transition ${
              activeTab === t.id
                ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            {language === 'hi' ? t.labelHi : t.labelEn}
          </button>
        ))}
      </div>

      {/* TAB 1: Jobs Section */}
      {activeTab === 'jobs' && (
        <div className="space-y-3">
          {/* Filters */}
          <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar">
            {[
              { id: 'all', label: 'सभी (All)' },
              { id: 'bihar', label: 'बिहार स्पेशल (Bihar)' },
              { id: 'central', label: 'केंद्रीय भर्ती (Central)' },
              { id: 'saved', label: `बुकमार्क (${bookmarkedJobs.length})` },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedFilter(f.id as any)}
                className={`py-1.5 px-3 rounded-xl text-[11px] font-bold shrink-0 transition ${
                  selectedFilter === f.id
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Job List */}
          <div className="space-y-3">
            {filteredJobs.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 text-center text-xs text-slate-400">
                कोई भर्ती नहीं मिली (No saved jobs)
              </div>
            ) : (
              filteredJobs.map((job) => {
                const isSaved = bookmarkedJobs.includes(job.id);
                return (
                  <div
                    key={job.id}
                    className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3 transition hover:shadow-md"
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-0.5">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400">
                          {job.department}
                        </span>
                        <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white pt-1">
                          {job.title}
                        </h3>
                      </div>

                      <button
                        onClick={() => toggleBookmarkJob(job.id)}
                        className={`p-1.5 rounded-full transition ${
                          isSaved
                            ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40'
                            : 'text-slate-400 hover:text-slate-600'
                        }`}
                      >
                        <Bookmark
                          className="w-4 h-4"
                          fill={isSaved ? 'currentColor' : 'none'}
                        />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300">
                      <div>
                        <span className="text-slate-400 block">कुल पद (Posts):</span>
                        <span className="font-bold text-slate-900 dark:text-white">
                          {job.totalPosts}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">योग्यता (Eligibility):</span>
                        <span className="font-bold text-slate-900 dark:text-white">
                          {job.qualification}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">वेतनमान (Salary):</span>
                        <span className="font-bold text-slate-900 dark:text-white">{job.salary}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">अंतिम तिथि (Last Date):</span>
                        <span className="font-bold text-red-500">{job.lastDate}</span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 pt-1">
                      <a
                        href={job.officialUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow transition flex items-center justify-center space-x-1.5"
                      >
                        <span>{language === 'hi' ? 'आधिकारिक नोटिफिकेशन व आवेदन' : 'Apply Official'}</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* TAB 2: Online Mock Test Quiz */}
      {activeTab === 'quiz' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4">
          {!isQuizFinished ? (
            <>
              {/* Quiz Progress Header */}
              <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                <span className="text-emerald-600 dark:text-emerald-400 flex items-center space-x-1">
                  <Award className="w-4 h-4" />
                  <span>
                    प्रश्न {currentQIndex + 1} / {MOCK_QUIZ_QUESTIONS.length}
                  </span>
                </span>
                <span>स्कोर: {quizScore} अंक</span>
              </div>

              {/* Question Text */}
              <div className="p-3 bg-emerald-50/60 dark:bg-slate-800/80 rounded-2xl border border-emerald-100 dark:border-slate-700">
                <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white leading-relaxed">
                  {language === 'hi'
                    ? MOCK_QUIZ_QUESTIONS[currentQIndex].questionHi
                    : MOCK_QUIZ_QUESTIONS[currentQIndex].questionEn}
                </h3>
              </div>

              {/* Options */}
              <div className="space-y-2">
                {(language === 'hi'
                  ? MOCK_QUIZ_QUESTIONS[currentQIndex].optionsHi
                  : MOCK_QUIZ_QUESTIONS[currentQIndex].optionsEn
                ).map((opt, i) => {
                  const isCorrect = i === MOCK_QUIZ_QUESTIONS[currentQIndex].correctIndex;
                  const isChosen = selectedAnswer === i;

                  let optClass = 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200';
                  if (selectedAnswer !== null) {
                    if (isCorrect) {
                      optClass = 'bg-green-100 dark:bg-green-950/60 border-green-500 text-green-900 dark:text-green-200 font-bold';
                    } else if (isChosen) {
                      optClass = 'bg-red-100 dark:bg-red-950/60 border-red-500 text-red-900 dark:text-red-200 font-bold';
                    }
                  }

                  return (
                    <button
                      key={i}
                      onClick={() => handleSelectOption(i)}
                      className={`w-full p-2.5 rounded-xl border text-xs text-left flex items-center justify-between transition ${optClass}`}
                    >
                      <span>{opt}</span>
                      {selectedAnswer !== null && isCorrect && (
                        <CheckCircle className="w-4 h-4 text-green-600 shrink-0" />
                      )}
                      {selectedAnswer !== null && isChosen && !isCorrect && (
                        <XCircle className="w-4 h-4 text-red-600 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Explanation in Hindi */}
              {showExplanation && (
                <div className="p-3 bg-slate-50 dark:bg-slate-800/90 rounded-2xl border text-xs text-slate-700 dark:text-slate-300 space-y-1 animate-in fade-in">
                  <span className="font-bold text-emerald-600 block">व्याख्या (Solution):</span>
                  <p className="leading-relaxed">
                    {language === 'hi'
                      ? MOCK_QUIZ_QUESTIONS[currentQIndex].explanationHi
                      : MOCK_QUIZ_QUESTIONS[currentQIndex].explanationEn}
                  </p>
                </div>
              )}

              {/* Next Button */}
              {selectedAnswer !== null && (
                <button
                  onClick={handleNextQuestion}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow transition active:scale-95"
                >
                  {currentQIndex === MOCK_QUIZ_QUESTIONS.length - 1
                    ? (language === 'hi' ? 'स्कोरकार्ड देखें' : 'View Results')
                    : (language === 'hi' ? 'अगला प्रश्न' : 'Next Question')}
                </button>
              )}
            </>
          ) : (
            /* Quiz Scorecard Result */
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center mx-auto shadow-md">
                <Award className="w-9 h-9" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                {language === 'hi' ? 'मॉक टेस्ट समाप्त!' : 'Test Completed!'}
              </h3>
              <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
                आपका कुल स्कोर:{' '}
                <span className="text-xl font-black text-emerald-600">
                  {quizScore} / {MOCK_QUIZ_QUESTIONS.length}
                </span>
              </p>
              <button
                onClick={resetQuiz}
                className="py-2.5 px-6 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow hover:bg-emerald-700 transition inline-flex items-center space-x-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'दोबारा टेस्ट दें' : 'Retake Test'}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Current Affairs & Notes */}
      {activeTab === 'current-affairs' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            {language === 'hi' ? 'आज के मुख्य करेंट अफेयर्स व नोट्स' : 'Daily Current Affairs & Notes'}
          </h3>

          <div className="space-y-2.5 text-xs">
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
              <span className="text-[10px] text-emerald-600 font-bold uppercase">राष्ट्रीय घटनाक्रम</span>
              <h4 className="font-bold text-slate-900 dark:text-white">
                भारत सरकार द्वारा डिजिटल नागरिक सेवाओं के सरलीकरण हेतु नया ई-पोर्टल 2026 शुरू
              </h4>
              <p className="text-slate-500 leading-relaxed text-[11px]">
                ग्रामीण नागरिकों को एक ही प्लेटफॉर्म पर 100+ सरकारी योजनाओं के आवेदन की सुविधा प्रदान की गई।
              </p>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
              <span className="text-[10px] text-orange-600 font-bold uppercase">बिहार स्पेशल GK</span>
              <h4 className="font-bold text-slate-900 dark:text-white">
                राजगीर में अंतरराष्ट्रीय खेल परिसर एवं आधुनिक डिजिटल अकादमी का लोकार्पण
              </h4>
              <p className="text-slate-500 leading-relaxed text-[11px]">
                प्रतियोगी परीक्षाओं में खेल एवं संस्कृति से जुड़े प्रश्नों के लिए विशेष तथ्य।
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
