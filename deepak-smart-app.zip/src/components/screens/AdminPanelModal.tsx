import React, { useState } from 'react';
import {
  X,
  Shield,
  Plus,
  Send,
  Users,
  Activity,
  Briefcase,
  Bell,
  CheckCircle,
  Lock,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AdminPanelModal: React.FC = () => {
  const {
    isAdminModalOpen,
    setIsAdminModalOpen,
    addJobNotification,
    addNotification,
    language,
  } = useApp();

  const [pin, setPin] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState<'analytics' | 'post-job' | 'broadcast'>('analytics');

  // Job form
  const [jobTitle, setJobTitle] = useState('');
  const [jobDept, setJobDept] = useState('');
  const [jobPosts, setJobPosts] = useState('');
  const [jobQual, setJobQual] = useState('');
  const [jobLastDate, setJobLastDate] = useState('2026-12-31');
  const [jobUrl, setJobUrl] = useState('');

  // Notification form
  const [alertTitle, setAlertTitle] = useState('');
  const [alertMsg, setAlertMsg] = useState('');

  const [feedback, setFeedback] = useState('');

  const handleVerifyPin = () => {
    if (pin === '1234' || pin === 'admin') {
      setIsAuthenticated(true);
    } else {
      alert(language === 'hi' ? 'गलत एडमिन पिन! (डिफ़ॉल्ट पिन 1234 है)' : 'Incorrect PIN! (Default is 1234)');
    }
  };

  const handlePostJob = async () => {
    if (!jobTitle.trim()) return;

    const newJob = {
      id: `job-${Date.now()}`,
      title: jobTitle,
      department: jobDept || 'Govt Department',
      totalPosts: jobPosts || '10,000+',
      qualification: jobQual || '10+2 / Graduation',
      ageLimit: '18 - 35 Years',
      lastDate: jobLastDate,
      category: 'Central / State',
      salary: 'Level-3 to Level-5',
      officialUrl: jobUrl || 'https://www.india.gov.in',
      status: 'Active',
      featured: true,
    };

    try {
      await fetch('/api/admin/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newJob),
      });
    } catch (e) {}

    addJobNotification(newJob);
    setJobTitle('');
    setJobDept('');
    setJobPosts('');
    setFeedback('सरकारी भर्ती सफलतापूर्वक प्रकाशित हो गई!');
    setTimeout(() => setFeedback(''), 3000);
  };

  const handleSendBroadcast = async () => {
    if (!alertTitle.trim()) return;

    try {
      await fetch('/api/admin/announcements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: alertTitle, message: alertMsg, type: 'alert' }),
      });
    } catch (e) {}

    addNotification({
      title: alertTitle,
      message: alertMsg,
      type: 'alert',
      linkTab: 'services',
    });

    setAlertTitle('');
    setAlertMsg('');
    setFeedback('पुश नोटिफिकेशन सभी यूज़र्स को भेज दी गई!');
    setTimeout(() => setFeedback(''), 3000);
  };

  if (!isAdminModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 select-none animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-3xl p-5 shadow-2xl border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-white relative overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => setIsAdminModalOpen(false)}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        {!isAuthenticated ? (
          /* Authentication Screen */
          <div className="py-6 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-red-100 dark:bg-red-950/60 text-red-600 flex items-center justify-center mx-auto shadow-sm">
              <Lock className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Admin Control Panel
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                सुरक्षित एडमिन 4-अंकीय पिन दर्ज करें (डिफ़ॉल्ट: 1234)
              </p>
            </div>

            <div className="max-w-[200px] mx-auto">
              <input
                type="password"
                maxLength={4}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleVerifyPin()}
                placeholder="••••"
                className="w-full text-center tracking-widest text-xl font-bold bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>

            <button
              onClick={handleVerifyPin}
              className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow transition active:scale-95"
            >
              लॉगिन करें (Verify Admin)
            </button>
          </div>
        ) : (
          /* Admin Dashboard */
          <div className="space-y-4 pt-1">
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-red-500" />
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                  Admin Dashboard
                </h3>
                <span className="text-[10px] text-green-500 font-bold">● Live Master Session</span>
              </div>
            </div>

            {/* Admin Tabs */}
            <div className="grid grid-cols-3 gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-[10px] font-bold">
              {[
                { id: 'analytics', label: 'एनालिटिक्स' },
                { id: 'post-job', label: 'जॉब पोस्ट' },
                { id: 'broadcast', label: 'अलर्ट भेजें' },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id as any)}
                  className={`py-1.5 rounded-lg text-center transition ${
                    activeTab === t.id
                      ? 'bg-red-600 text-white shadow'
                      : 'text-slate-600 dark:text-slate-400 hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Tab 1: Analytics */}
            {activeTab === 'analytics' && (
              <div className="space-y-2.5">
                <div className="grid grid-cols-2 gap-2 text-center text-xs">
                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border">
                    <Users className="w-4 h-4 text-blue-500 mx-auto mb-1" />
                    <span className="text-[10px] text-slate-400 block">सक्रिय उपभोक्ता</span>
                    <span className="text-base font-extrabold text-slate-900 dark:text-white">
                      14,892
                    </span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border">
                    <Activity className="w-4 h-4 text-green-500 mx-auto mb-1" />
                    <span className="text-[10px] text-slate-400 block">AI प्रश्न हल किए</span>
                    <span className="text-base font-extrabold text-slate-900 dark:text-white">
                      89,420
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 text-xs space-y-1">
                  <span className="font-bold text-[11px] block">सर्वर व मॉडल स्थिति:</span>
                  <div className="flex justify-between text-slate-400 text-[10px]">
                    <span>AI इंजन:</span>
                    <span className="text-green-500 font-bold">Gemini 3.8 Flash (Active)</span>
                  </div>
                  <div className="flex justify-between text-slate-400 text-[10px]">
                    <span>डेटाबेस / स्टोरेज:</span>
                    <span className="text-blue-500 font-bold">Local SQLite & Offline DB</span>
                  </div>
                  <div className="flex justify-between text-slate-400 text-[10px]">
                    <span>वर्शन:</span>
                    <span className="font-bold">v2.5.0-PRO (Commercial)</span>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Post Job */}
            {activeTab === 'post-job' && (
              <div className="space-y-2 text-xs">
                <input
                  type="text"
                  placeholder="भर्ती का शीर्षक (Title)"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 p-2 rounded-xl text-xs border border-slate-200"
                />
                <input
                  type="text"
                  placeholder="विभाग (Department)"
                  value={jobDept}
                  onChange={(e) => setJobDept(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 p-2 rounded-xl text-xs border border-slate-200"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="कुल पद (Posts)"
                    value={jobPosts}
                    onChange={(e) => setJobPosts(e.target.value)}
                    className="bg-slate-50 dark:bg-slate-800 p-2 rounded-xl text-xs border border-slate-200"
                  />
                  <input
                    type="date"
                    value={jobLastDate}
                    onChange={(e) => setJobLastDate(e.target.value)}
                    className="bg-slate-50 dark:bg-slate-800 p-2 rounded-xl text-xs border border-slate-200"
                  />
                </div>
                <input
                  type="text"
                  placeholder="आधिकारिक लिंक (Official Portal URL)"
                  value={jobUrl}
                  onChange={(e) => setJobUrl(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 p-2 rounded-xl text-xs border border-slate-200"
                />
                <button
                  onClick={handlePostJob}
                  className="w-full py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow transition"
                >
                  भर्ती नोटिफिकेशन लाइव करें
                </button>
              </div>
            )}

            {/* Tab 3: Broadcast */}
            {activeTab === 'broadcast' && (
              <div className="space-y-2 text-xs">
                <input
                  type="text"
                  placeholder="अलर्ट का शीर्षक"
                  value={alertTitle}
                  onChange={(e) => setAlertTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 p-2 rounded-xl text-xs border border-slate-200"
                />
                <textarea
                  rows={3}
                  placeholder="सूचना का पूरा संदेश..."
                  value={alertMsg}
                  onChange={(e) => setAlertMsg(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 p-2 rounded-xl text-xs border border-slate-200"
                />
                <button
                  onClick={handleSendBroadcast}
                  className="w-full py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow transition flex items-center justify-center space-x-1"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>सभी यूज़र्स को तुरंत भेजें</span>
                </button>
              </div>
            )}

            {feedback && (
              <div className="p-2 rounded-xl bg-green-50 text-green-700 text-xs font-semibold flex items-center justify-center space-x-1.5 animate-in fade-in">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span>{feedback}</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
