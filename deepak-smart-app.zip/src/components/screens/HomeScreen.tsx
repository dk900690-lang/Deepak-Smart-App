import React, { useState } from 'react';
import {
  Search,
  Sparkles,
  Camera,
  FileText,
  Briefcase,
  ShieldCheck,
  Building,
  GraduationCap,
  Wrench,
  ArrowRight,
  Zap,
  TrendingUp,
  Bookmark,
  Share2,
  Calendar,
  CheckCircle2,
  Clock,
  Printer,
  QrCode,
  CreditCard,
  Mic,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../data/mockData';
import { ServiceSubTab, MainTab } from '../../types';

export const HomeScreen: React.FC = () => {
  const {
    language,
    user,
    setCurrentTab,
    setServiceSubTab,
    searchQuery,
    setSearchQuery,
    setIsVoiceModalOpen,
    jobsList,
    notifications,
  } = useApp();

  const t = TRANSLATIONS[language];

  // Greeting based on current hour
  const currentHour = new Date().getHours();
  const greeting =
    currentHour < 12
      ? t.greetingMorning
      : currentHour < 17
      ? t.greetingAfternoon
      : t.greetingEvening;

  const todayDate = new Date().toLocaleDateString(
    language === 'hi' ? 'hi-IN' : 'en-IN',
    { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }
  );

  // 8 Main Categories
  const categories: {
    id: ServiceSubTab;
    tab: MainTab;
    titleHi: string;
    titleEn: string;
    descHi: string;
    descEn: string;
    icon: React.FC<{ className?: string }>;
    gradient: string;
    count: string;
  }[] = [
    {
      id: 'photo',
      tab: 'services',
      titleHi: 'AI फोटो स्टूडियो',
      titleEn: 'AI Photo Studio',
      descHi: 'पासपोर्ट फोटो, 8-इन-1 शीट, बैकग्राउंड रिमूवर, HD एन्हांसर',
      descEn: 'Passport photo, 8-in-1 sheet, BG remover, HD enhance',
      icon: Camera,
      gradient: 'from-amber-500 to-orange-600',
      count: '12 Tools',
    },
    {
      id: 'pdf',
      tab: 'services',
      titleHi: 'स्मार्ट PDF टूल्स',
      titleEn: 'Smart PDF Tools',
      descHi: 'इमेज टू PDF, डॉक्युमेंट स्कैनर, OCR, साइज कंप्रेसर',
      descEn: 'Image to PDF, Doc scanner, OCR text, compress',
      icon: FileText,
      gradient: 'from-red-500 to-rose-600',
      count: '8 Tools',
    },
    {
      id: 'csc',
      tab: 'services',
      titleHi: 'CSC डिजिटल सेवाएं',
      titleEn: 'CSC Digital Services',
      descHi: 'आधार, पैन, राशन, RTPS जाति/आय/निवास, e-श्रम पोर्टल',
      descEn: 'Aadhaar, PAN, Ration card, Bihar RTPS, e-Shram',
      icon: Building,
      gradient: 'from-blue-600 to-cyan-600',
      count: '18 Services',
    },
    {
      id: 'jobs',
      tab: 'services',
      titleHi: 'सरकारी नौकरी व परीक्षा',
      titleEn: 'Govt Jobs & Exams',
      descHi: 'बिहार व केंद्र सरकारी भर्ती, एडमिट कार्ड, सिलेबस',
      descEn: 'Bihar & Central recruitment, admit cards, syllabus',
      icon: Briefcase,
      gradient: 'from-emerald-500 to-teal-600',
      count: 'New Active',
    },
    {
      id: 'business',
      tab: 'services',
      titleHi: 'स्मार्ट बिजनेस टूल्स',
      titleEn: 'Smart Business Tools',
      descHi: 'GST बिल/इनवॉइस, विजिटिंग कार्ड, UPI QR कोड, खाता',
      descEn: 'GST invoice, visiting cards, UPI QR, cashbook',
      icon: ShieldCheck,
      gradient: 'from-indigo-600 to-violet-600',
      count: '7 Tools',
    },
    {
      id: 'all',
      tab: 'services',
      titleHi: 'ऑनलाइन टेस्ट व क्विज़',
      titleEn: 'Online Mock Tests',
      descHi: 'डेली करेंट अफेयर्स, बिहार GK, स्कोरकार्ड के साथ टेस्ट',
      descEn: 'Daily current affairs, Bihar GK, timed quizzes',
      icon: GraduationCap,
      gradient: 'from-purple-600 to-pink-600',
      count: 'Daily Free',
    },
    {
      id: 'all',
      tab: 'ai-assistant',
      titleHi: 'दीपक AI लेखक',
      titleEn: 'Deepak AI Writer',
      descHi: 'बैंक/सरकारी आवेदन पत्र, ईमेल, YouTube टाइटल, पोस्टर',
      descEn: 'Bank/Govt applications, emails, YouTube tags, letters',
      icon: Sparkles,
      gradient: 'from-orange-500 to-amber-600',
      count: 'Gemini 3.8',
    },
    {
      id: 'business',
      tab: 'services',
      titleHi: 'साइबर कैफे कैलकुलेटर',
      titleEn: 'CSC Rate Calculator',
      descHi: 'प्रिंटिंग, लेमिनेशन, फॉर्म फीस का तुरंत कुल बिल बनाएं',
      descEn: 'Calculate Xerox, color print, lamination charges',
      icon: Wrench,
      gradient: 'from-slate-700 to-slate-900',
      count: 'Quick Calc',
    },
  ];

  // Filtered categories based on search
  const filteredCategories = categories.filter((c) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.titleHi.toLowerCase().includes(q) ||
      c.titleEn.toLowerCase().includes(q) ||
      c.descHi.toLowerCase().includes(q) ||
      c.descEn.toLowerCase().includes(q)
    );
  });

  const handleOpenCategory = (cat: typeof categories[0]) => {
    setCurrentTab(cat.tab);
    setServiceSubTab(cat.id);
  };

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto select-none space-y-4">
      {/* 1. Greeting & Profile Banner */}
      <div className="bg-gradient-to-br from-[#102A43] via-[#163554] to-[#1F4368] rounded-3xl p-4 text-white shadow-xl relative overflow-hidden border border-orange-500/20">
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-orange-500/20 rounded-full blur-2xl"></div>
        <div className="relative z-10 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-1.5 text-xs text-orange-300 font-semibold mb-0.5">
              <Calendar className="w-3.5 h-3.5" />
              <span>{todayDate}</span>
            </div>
            <h2 className="text-xl font-extrabold tracking-tight">
              {greeting}, {user.name.split(' ')[0]} जी! 👋
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'hi'
                ? 'आज आप कौन सी डिजिटल सेवा इस्तेमाल करना चाहते हैं?'
                : 'Which digital service would you like to use today?'}
            </p>
          </div>

          <div
            onClick={() => setCurrentTab('profile')}
            className="cursor-pointer relative w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-orange-500 p-0.5 shadow-md shrink-0 active:scale-95 transition"
          >
            <img
              src={user.avatarUrl}
              alt={user.name}
              className="w-full h-full object-cover rounded-[14px]"
            />
            {user.isVip && (
              <span className="absolute -bottom-1 -right-1 bg-amber-400 text-[#102A43] text-[9px] font-black px-1.5 rounded-full ring-2 ring-[#102A43]">
                PRO
              </span>
            )}
          </div>
        </div>

        {/* Quick Service Highlights */}
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-orange-200">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
            <span className="font-medium text-[11px]">
              {language === 'hi' ? 'सीएससी सेंटर: सक्रिय' : 'CSC Center: Active'}
            </span>
          </div>
          <button
            onClick={() => {
              setCurrentTab('services');
              setServiceSubTab('csc');
            }}
            className="text-[11px] font-bold text-amber-300 hover:text-amber-200 flex items-center space-x-1"
          >
            <span>{language === 'hi' ? 'सभी 18 सेवाएं देखें' : 'View 18 Services'}</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* 2. Unified Search Anything Bar */}
      <div className="relative">
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full bg-white dark:bg-slate-900 text-slate-800 dark:text-white pl-10 pr-12 py-3 rounded-2xl text-xs sm:text-sm font-medium shadow-sm border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition placeholder:text-slate-400"
          />
          <button
            onClick={() => setIsVoiceModalOpen(true)}
            className="absolute right-2.5 p-2 rounded-xl bg-orange-500 text-white shadow-sm hover:bg-orange-600 transition active:scale-95"
            title="बोलकर खोजें (Voice Search)"
          >
            <Mic className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 3. Deepak AI Assistant Card Banner */}
      <div
        onClick={() => setCurrentTab('ai-assistant')}
        className="bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 rounded-3xl p-4 text-white shadow-lg shadow-orange-500/20 cursor-pointer hover:shadow-xl transition transform active:scale-[0.99] relative overflow-hidden group"
      >
        <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-white/10 rounded-full blur-xl group-hover:scale-125 transition duration-500"></div>
        <div className="flex items-center justify-between relative z-10">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[10px] font-bold tracking-wide backdrop-blur-sm">
              <Sparkles className="w-3 h-3" />
              <span>POWERED BY GEMINI 3.8 FLASH</span>
            </div>
            <h3 className="text-base sm:text-lg font-extrabold flex items-center space-x-1.5">
              <span>{language === 'hi' ? 'दीपक AI से कुछ भी पूछें' : 'Ask Deepak AI Anything'}</span>
              <span className="text-xs">⚡</span>
            </h3>
            <p className="text-xs text-orange-100 font-medium line-clamp-1">
              {language === 'hi'
                ? 'सरकारी फॉर्म, बैंक आवेदन पत्र, फोटो सुधार या कोई भी सवाल'
                : 'Govt forms, bank letters, photo help, or general queries'}
            </p>
          </div>

          <div className="w-11 h-11 rounded-2xl bg-white text-orange-600 flex items-center justify-center font-bold shadow-md shrink-0 group-hover:rotate-6 transition">
            <Zap className="w-6 h-6 fill-current text-orange-500" />
          </div>
        </div>

        {/* Quick prompt chips */}
        <div className="mt-3 pt-2.5 border-t border-white/20 flex items-center space-x-2 overflow-x-auto no-scrollbar text-[10px]">
          <span className="bg-black/20 px-2 py-0.5 rounded-md shrink-0">
            {language === 'hi' ? '✍️ बैंक खाता ट्रांसफर आवेदन' : '✍️ Bank Account Transfer Letter'}
          </span>
          <span className="bg-black/20 px-2 py-0.5 rounded-md shrink-0">
            {language === 'hi' ? '📄 जाति प्रमाण पत्र नियम' : '📄 Caste Certificate Rules'}
          </span>
          <span className="bg-black/20 px-2 py-0.5 rounded-md shrink-0">
            {language === 'hi' ? '📷 फोटो 50KB में कंप्रेस' : '📷 Compress photo to 50KB'}
          </span>
        </div>
      </div>

      {/* 4. Service Categories Grid */}
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center space-x-1.5">
            <TrendingUp className="w-4 h-4 text-orange-500" />
            <span>{language === 'hi' ? 'मुख्य डिजिटल सुविधाएं' : 'Core Digital Services'}</span>
          </h3>
          <span className="text-[11px] font-semibold text-slate-400">8 Categories</span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {filteredCategories.map((cat, idx) => {
            const Icon = cat.icon;
            const title = language === 'hi' ? cat.titleHi : cat.titleEn;
            const desc = language === 'hi' ? cat.descHi : cat.descEn;

            return (
              <div
                key={idx}
                onClick={() => handleOpenCategory(cat)}
                className="bg-white dark:bg-slate-900 rounded-2xl p-3 shadow-sm hover:shadow-md border border-slate-200/80 dark:border-slate-800 cursor-pointer transition transform active:scale-95 flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div
                      className={`w-9 h-9 rounded-xl bg-gradient-to-br ${cat.gradient} text-white flex items-center justify-center shadow-sm group-hover:scale-110 transition`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400">
                      {cat.count}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-orange-500 transition line-clamp-1">
                    {title}
                  </h4>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {desc}
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[10px] text-orange-600 dark:text-orange-400 font-bold">
                  <span>{language === 'hi' ? 'खोलें' : 'Open'}</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. Trending Govt Jobs Ticker */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
            <h3 className="text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider">
              {language === 'hi' ? 'ताज़ा सरकारी भर्ती अलर्ट 2026' : 'Latest Govt Vacancies 2026'}
            </h3>
          </div>
          <button
            onClick={() => {
              setCurrentTab('services');
              setServiceSubTab('jobs');
            }}
            className="text-[11px] font-bold text-orange-600 dark:text-orange-400 hover:underline"
          >
            {language === 'hi' ? 'सभी देखें' : 'View All'}
          </button>
        </div>

        <div className="space-y-2">
          {jobsList.slice(0, 2).map((job) => (
            <div
              key={job.id}
              onClick={() => {
                setCurrentTab('services');
                setServiceSubTab('jobs');
              }}
              className="p-2.5 rounded-xl bg-orange-50/40 dark:bg-slate-800/60 border border-orange-100 dark:border-slate-700/60 hover:bg-orange-50 dark:hover:bg-slate-800 cursor-pointer transition flex items-center justify-between"
            >
              <div className="space-y-0.5">
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-orange-500/10 text-orange-600 dark:text-orange-400">
                  {job.department}
                </span>
                <h5 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                  {job.title}
                </h5>
                <p className="text-[10px] text-slate-500">
                  पद: <b className="text-slate-700 dark:text-slate-300">{job.totalPosts}</b> • अंतिम तिथि: <span className="text-red-500 font-semibold">{job.lastDate}</span>
                </p>
              </div>
              <ArrowRight className="w-4 h-4 text-orange-500 shrink-0 ml-2" />
            </div>
          ))}
        </div>
      </div>

      {/* 6. Smart Bharat Mode: Quick Tools Row */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-slate-900 dark:to-[#102A43] rounded-3xl p-4 border border-orange-200 dark:border-slate-800">
        <div className="flex items-center space-x-2 mb-3">
          <div className="p-1 rounded-lg bg-orange-500 text-white">
            <Zap className="w-3.5 h-3.5" />
          </div>
          <div>
            <h4 className="text-xs font-extrabold text-slate-900 dark:text-white">
              {language === 'hi' ? 'स्मार्ट भारत मोड (Instant Actions)' : 'Smart Bharat Quick Actions'}
            </h4>
            <p className="text-[10px] text-slate-500">
              {language === 'hi' ? 'एक क्लिक में सामान्य कार्य पूरे करें' : 'Finish daily tasks in one click'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-2 text-center">
          <button
            onClick={() => {
              setCurrentTab('services');
              setServiceSubTab('photo');
            }}
            className="flex flex-col items-center p-2 rounded-2xl bg-white dark:bg-slate-800 shadow-xs hover:shadow-md transition active:scale-95"
          >
            <div className="w-8 h-8 rounded-xl bg-orange-100 dark:bg-orange-950/60 text-orange-600 flex items-center justify-center mb-1">
              <Printer className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-slate-700 dark:text-slate-200 line-clamp-1">
              8x Photo
            </span>
          </button>

          <button
            onClick={() => {
              setCurrentTab('services');
              setServiceSubTab('pdf');
            }}
            className="flex flex-col items-center p-2 rounded-2xl bg-white dark:bg-slate-800 shadow-xs hover:shadow-md transition active:scale-95"
          >
            <div className="w-8 h-8 rounded-xl bg-red-100 dark:bg-red-950/60 text-red-600 flex items-center justify-center mb-1">
              <FileText className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-slate-700 dark:text-slate-200 line-clamp-1">
              Scan Doc
            </span>
          </button>

          <button
            onClick={() => {
              setCurrentTab('services');
              setServiceSubTab('business');
            }}
            className="flex flex-col items-center p-2 rounded-2xl bg-white dark:bg-slate-800 shadow-xs hover:shadow-md transition active:scale-95"
          >
            <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center mb-1">
              <QrCode className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-slate-700 dark:text-slate-200 line-clamp-1">
              UPI QR
            </span>
          </button>

          <button
            onClick={() => {
              setCurrentTab('services');
              setServiceSubTab('csc');
            }}
            className="flex flex-col items-center p-2 rounded-2xl bg-white dark:bg-slate-800 shadow-xs hover:shadow-md transition active:scale-95"
          >
            <div className="w-8 h-8 rounded-xl bg-green-100 dark:bg-green-950/60 text-green-600 flex items-center justify-center mb-1">
              <CreditCard className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-slate-700 dark:text-slate-200 line-clamp-1">
              RTPS फॉर्म
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
