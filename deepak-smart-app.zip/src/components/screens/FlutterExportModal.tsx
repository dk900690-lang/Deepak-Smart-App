import React, { useState } from 'react';
import { X, Code, Download, Copy, Check, Smartphone, Terminal, BookOpen, Layers } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const FlutterExportModal: React.FC = () => {
  const { isExportModalOpen, setIsExportModalOpen, language } = useApp();
  const [selectedFile, setSelectedFile] = useState<string>('pubspec.yaml');
  const [copied, setCopied] = useState(false);

  const fileContents: Record<string, string> = {
    'pubspec.yaml': `name: deepak_smart_app
description: "Deepak Smart App - आपका अपना डिजिटल स्मार्ट साथी. Commercial Indian Super App combining AI, CSC Digital Seva, Photo Studio, PDF Tools & Business utilities."
publish_to: 'none'
version: 2.5.0+10

environment:
  sdk: '>=3.2.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.8
  google_fonts: ^6.2.1
  flutter_riverpod: ^2.5.1
  http: ^1.2.1
  camera: ^0.10.5+9
  image_picker: ^1.1.2
  image_cropper: ^6.0.0
  image: ^4.2.0
  pdf: ^3.10.8
  printing: ^5.13.1
  path_provider: ^2.1.3
  qr_flutter: ^4.1.0
  speech_to_text: ^6.6.1
  flutter_tts: ^4.0.2
  shared_preferences: ^2.2.3
  url_launcher: ^6.3.0
  share_plus: ^9.0.0
  flutter_local_notifications: ^17.2.1

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^4.0.0

flutter:
  uses-material-design: true
  assets:
    - assets/images/
    - assets/icons/`,

    'AndroidManifest.xml': `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.deepaksmart.app">

    <!-- Permissions required for Deepak Smart App -->
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29"/>
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
    <uses-permission android:name="android.permission.VIBRATE"/>

    <application
        android:label="Deepak Smart App"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher"
        android:theme="@style/LaunchTheme"
        android:roundIcon="@mipmap/ic_launcher_round">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">

            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
</manifest>`,

    'main.dart': `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Color(0xFF102A43),
      statusBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const DeepakSmartApp());
}

class DeepakSmartApp extends StatelessWidget {
  const DeepakSmartApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Deepak Smart App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        primaryColor: const Color(0xFFFF8C00),
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFF8C00),
          primary: const Color(0xFFFF8C00),
          secondary: const Color(0xFF102A43),
        ),
        textTheme: GoogleFonts.plusJakartaSansTextTheme(),
      ),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    HomeScreen(),
    AIAssistantScreen(),
    ServicesHubScreen(),
    MyFilesScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (idx) => setState(() => _currentIndex = idx),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'होम'),
          NavigationDestination(icon: Icon(Icons.smart_toy_rounded), label: 'दीपक AI'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'सेवाएं'),
          NavigationDestination(icon: Icon(Icons.folder_shared_rounded), label: 'फाइल्स'),
          NavigationDestination(icon: Icon(Icons.person_rounded), label: 'प्रोफाइल'),
        ],
      ),
    );
  }
}

// Sub-screens implemented modularly under lib/screens/...
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('दीपक स्मार्ट ऐप')),
    body: const Center(child: Text('आपका अपना डिजिटल स्मार्ट साथी')),
  );
}

class AIAssistantScreen extends StatelessWidget {
  const AIAssistantScreen({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold();
}

class ServicesHubScreen extends StatelessWidget {
  const ServicesHubScreen({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold();
}

class MyFilesScreen extends StatelessWidget {
  const MyFilesScreen({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold();
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold();
}`,

    'BUILD_APK_INSTRUCTIONS.md': `# DEEPAK SMART APP - ANDROID APK & FLUTTER BUILD GUIDE

## 1. Prerequisites
- Flutter SDK (>= 3.2.0)
- Android Studio with Android SDK 34
- Java JDK 17

## 2. Fast Build Commands:
\`\`\`bash
# 1. Fetch all dependencies
flutter pub get

# 2. Build Debug APK (For local test):
flutter build apk --debug
# Output: build/app/outputs/flutter-apk/app-debug.apk

# 3. Build Production Signed Release APK:
flutter build apk --release --split-per-abi
# Output: build/app/outputs/flutter-apk/app-arm64-v8a-release.apk
\`\`\`

## 3. Brand Identity Configurations:
- Package: \`com.deepaksmart.app\`
- App Name: \`Deepak Smart App\`
- Primary Saffron: \`#FF8C00\`
- Accent Navy: \`#102A43\`
- Tagline: "आपका अपना डिजिटल स्मार्ट साथी"`,
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(fileContents[selectedFile] || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadAll = () => {
    const fullContent = Object.entries(fileContents)
      .map(([name, content]) => `// ===================== File: ${name} =====================\n\n${content}\n\n`)
      .join('\n');

    const blob = new Blob([fullContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Deepak_Smart_App_Flutter_Android_Source_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!isExportModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 select-none animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-5 shadow-2xl border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-white relative flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center space-x-2">
            <Smartphone className="w-5 h-5 text-blue-500" />
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                Flutter & Android Code Exporter
              </h3>
              <p className="text-[10px] text-slate-400">
                Native Android Studio & Flutter Project Sources
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsExportModalOpen(false)}
            className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* File Tabs */}
        <div className="flex items-center space-x-1.5 py-2.5 overflow-x-auto no-scrollbar">
          {Object.keys(fileContents).map((fileName) => (
            <button
              key={fileName}
              onClick={() => setSelectedFile(fileName)}
              className={`py-1 px-2.5 rounded-xl text-[10px] font-bold shrink-0 transition ${
                selectedFile === fileName
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}
            >
              {fileName}
            </button>
          ))}
        </div>

        {/* Code Display Area */}
        <div className="flex-1 overflow-hidden flex flex-col bg-slate-950 rounded-2xl p-3 border border-slate-800 text-slate-200 font-mono text-[11px] relative">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-[10px] text-slate-400">
            <span>{selectedFile}</span>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopy}
                className="hover:text-white flex items-center space-x-1 transition"
              >
                {copied ? (
                  <Check className="w-3.5 h-3.5 text-green-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          <pre className="flex-1 overflow-auto py-2 leading-relaxed whitespace-pre-wrap select-text">
            {fileContents[selectedFile]}
          </pre>
        </div>

        {/* Bottom Actions */}
        <div className="pt-3 flex items-center space-x-2">
          <button
            onClick={handleDownloadAll}
            className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow flex items-center justify-center space-x-1.5 transition"
          >
            <Download className="w-4 h-4" />
            <span>Download Source Bundle (.txt)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
