import React from 'react';
import { Camera, FileText, Building, Briefcase, ShieldCheck, Grid } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ServiceSubTab } from '../../types';
import { CSCServicesScreen } from './CSCServicesScreen';
import { PhotoStudioScreen } from './PhotoStudioScreen';
import { PDFStudioScreen } from './PDFStudioScreen';
import { JobsEducationScreen } from './JobsEducationScreen';
import { BusinessToolsScreen } from './BusinessToolsScreen';

export const ServicesHubScreen: React.FC = () => {
  const { serviceSubTab, setServiceSubTab, language } = useApp();

  const subtabs: { id: ServiceSubTab; labelHi: string; labelEn: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'all', labelHi: 'सभी सेवाएं', labelEn: 'All Hub', icon: Grid },
    { id: 'photo', labelHi: 'फोटो स्टूडियो', labelEn: 'Photo Studio', icon: Camera },
    { id: 'pdf', labelHi: 'PDF टूल्स', labelEn: 'PDF Studio', icon: FileText },
    { id: 'csc', labelHi: 'CSC सेवाएं', labelEn: 'CSC Services', icon: Building },
    { id: 'jobs', labelHi: 'सरकारी नौकरी', labelEn: 'Govt Jobs', icon: Briefcase },
    { id: 'business', labelHi: 'बिजनेस टूल्स', labelEn: 'Business', icon: ShieldCheck },
  ];

  return (
    <div className="space-y-3">
      {/* Horizontal Subtab Switcher */}
      <div className="pt-2 px-3 sm:px-4 max-w-md mx-auto sticky top-0 bg-slate-100/90 dark:bg-slate-950/90 backdrop-blur-md z-30 select-none pb-1">
        <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar py-1">
          {subtabs.map((tab) => {
            const Icon = tab.icon;
            const isSelected = serviceSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setServiceSubTab(tab.id)}
                className={`py-1.5 px-3 rounded-2xl text-[11px] font-bold shrink-0 flex items-center space-x-1.5 transition active:scale-95 ${
                  isSelected
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-md shadow-orange-500/20'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? tab.labelHi : tab.labelEn}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Render Active Sub-service */}
      {serviceSubTab === 'photo' && <PhotoStudioScreen />}
      {serviceSubTab === 'pdf' && <PDFStudioScreen />}
      {serviceSubTab === 'csc' && <CSCServicesScreen />}
      {serviceSubTab === 'jobs' && <JobsEducationScreen />}
      {serviceSubTab === 'business' && <BusinessToolsScreen />}

      {serviceSubTab === 'all' && (
        <div className="pb-24 px-3 sm:px-4 max-w-md mx-auto space-y-4">
          {/* Quick jump cards */}
          <div className="space-y-3">
            {[
              {
                id: 'photo',
                title: 'AI Photo Studio',
                desc: '35x45mm Passport Photos, 8-on-1 Print Sheet, Signature Resizer & BG Remover',
                icon: Camera,
                color: 'from-amber-500 to-orange-600',
              },
              {
                id: 'pdf',
                title: 'Smart PDF & Document Studio',
                desc: 'Image to PDF, Mobile Scanner, OCR text extraction, Hindi Document Reader',
                icon: FileText,
                color: 'from-red-500 to-rose-600',
              },
              {
                id: 'csc',
                title: 'CSC & Digital Service Centre',
                desc: 'Aadhaar, PAN Card, Bihar RTPS, Ration Card, e-Shram & official portals',
                icon: Building,
                color: 'from-blue-600 to-indigo-600',
              },
              {
                id: 'jobs',
                title: 'Government Jobs & Education',
                desc: 'Central & Bihar vacancies, timed mock quiz with scoring, daily current affairs',
                icon: Briefcase,
                color: 'from-emerald-500 to-teal-600',
              },
              {
                id: 'business',
                title: 'Smart Business Tools',
                desc: 'GST Invoices, UPI QR standee, Visiting Card, Daily Khata cashbook, Price Calc',
                icon: ShieldCheck,
                color: 'from-indigo-600 to-violet-600',
              },
            ].map((card) => {
              const Icon = card.icon;
              return (
                <div
                  key={card.id}
                  onClick={() => setServiceSubTab(card.id as any)}
                  className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 cursor-pointer hover:shadow-md transition flex items-center space-x-3.5"
                >
                  <div
                    className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${card.color} text-white flex items-center justify-center shrink-0 shadow-md`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                      {card.title}
                    </h3>
                    <p className="text-[11px] text-slate-500 leading-relaxed mt-0.5">
                      {card.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
