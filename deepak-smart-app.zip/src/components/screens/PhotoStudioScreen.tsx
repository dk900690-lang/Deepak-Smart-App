import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Download,
  Camera,
  Layers,
  Palette,
  Sliders,
  FileCheck,
  Maximize2,
  FileText,
  RotateCw,
  Sparkles,
  Save,
  CheckCircle,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { jsPDF } from 'jspdf';

export const PhotoStudioScreen: React.FC = () => {
  const { language, saveFile } = useApp();

  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [activeTool, setActiveTool] = useState<
    'passport' | 'bg-color' | 'enhancer' | 'compress' | 'signature'
  >('passport');

  // Passport options
  const [passportLayout, setPassportLayout] = useState<'single' | '4-grid' | '8-sheet'>('8-sheet');
  const [addBorder, setAddBorder] = useState(true);

  // Background color options
  const [bgColor, setBgColor] = useState<string>('#2B50AA'); // Default Indian official studio blue

  // Enhancer filters
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [saturation, setSaturation] = useState<number>(100);
  const [sharpness, setSharpness] = useState<boolean>(true);

  // Compression target
  const [targetKb, setTargetKb] = useState<number>(50);
  const [compressedSize, setCompressedSize] = useState<string>('');

  const [savedSuccess, setSavedSuccess] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sample placeholder demo image if none uploaded
  useEffect(() => {
    // Generate a default high quality portrait sample
    const sample = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=500&q=80';
    setImageSrc(sample);
  }, []);

  // Redraw canvas whenever settings change
  useEffect(() => {
    if (!imageSrc) return;
    renderCanvas();
  }, [
    imageSrc,
    activeTool,
    passportLayout,
    addBorder,
    bgColor,
    brightness,
    contrast,
    saturation,
    sharpness,
  ]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImageSrc(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas || !imageSrc) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = imageSrc;
    img.onload = () => {
      // 1. Signature Resizer mode (Standard 140 x 60 px)
      if (activeTool === 'signature') {
        canvas.width = 280; // Retina 2x
        canvas.height = 120;
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Filter: high contrast B&W for clear ink
        ctx.filter = `contrast(180%) grayscale(100%) brightness(${brightness}%)`;
        ctx.drawImage(img, 10, 10, canvas.width - 20, canvas.height - 20);
        ctx.filter = 'none';

        // Add subtle crop guide line
        ctx.strokeStyle = '#D1D5DB';
        ctx.lineWidth = 1;
        ctx.strokeRect(0, 0, canvas.width, canvas.height);
        calculateFileSize();
        return;
      }

      // 2. 8-Photo Print Sheet (4x6 inch format, 1200 x 1800 px at 300 DPI)
      if (activeTool === 'passport' && passportLayout === '8-sheet') {
        canvas.width = 1200;
        canvas.height = 1800;

        // White background sheet
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Header watermark
        ctx.fillStyle = '#94A3B8';
        ctx.font = '24px sans-serif';
        ctx.fillText('Deepak Smart App - 4x6 Passport Photo Sheet (300 DPI)', 60, 60);

        // 8 photos: 2 columns x 4 rows
        const photoW = 480;
        const photoH = 360;
        const startX = 80;
        const startY = 120;
        const gapX = 80;
        const gapY = 60;

        for (let row = 0; row < 4; row++) {
          for (let col = 0; col < 2; col++) {
            const x = startX + col * (photoW + gapX);
            const y = startY + row * (photoH + gapY);

            // Draw individual photo
            ctx.save();
            ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;

            // Draw background fill if custom color set
            if (bgColor && bgColor !== '#FFFFFF') {
              ctx.fillStyle = bgColor;
              ctx.fillRect(x, y, photoW, photoH);
            }

            ctx.drawImage(img, x, y, photoW, photoH);
            ctx.restore();

            // Passport border
            if (addBorder) {
              ctx.strokeStyle = '#000000';
              ctx.lineWidth = 2;
              ctx.strokeRect(x, y, photoW, photoH);
            }
          }
        }
        calculateFileSize();
        return;
      }

      // 3. 4-Photo Grid (4 passport photos)
      if (activeTool === 'passport' && passportLayout === '4-grid') {
        canvas.width = 800;
        canvas.height = 800;
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        const photoW = 340;
        const photoH = 340;
        const coords = [
          [40, 40],
          [420, 40],
          [40, 420],
          [420, 420],
        ];

        coords.forEach(([x, y]) => {
          ctx.save();
          ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
          ctx.drawImage(img, x, y, photoW, photoH);
          ctx.restore();
          if (addBorder) {
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, photoW, photoH);
          }
        });
        calculateFileSize();
        return;
      }

      // 4. Single Passport / Enhancer / Color changer (3.5 x 4.5 cm ratio -> 420 x 540 px)
      canvas.width = 420;
      canvas.height = 540;

      ctx.save();
      ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;

      // Draw background tint/color
      if (activeTool === 'bg-color') {
        ctx.fillStyle = bgColor;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      ctx.restore();

      if (addBorder) {
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 3;
        ctx.strokeRect(0, 0, canvas.width, canvas.height);
      }

      calculateFileSize();
    };
  };

  const calculateFileSize = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    const head = 'data:image/jpeg;base64,';
    const sizeInBytes = Math.round(((dataUrl.length - head.length) * 3) / 4);
    const sizeInKb = (sizeInBytes / 1024).toFixed(1);
    setCompressedSize(`${sizeInKb} KB`);
  };

  // Download image
  const handleDownloadImage = (format: 'jpg' | 'png') => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let dataUrl = '';
    if (format === 'png') {
      dataUrl = canvas.toDataURL('image/png');
    } else {
      // Calculate quality to match targetKb if compression is requested
      let quality = 0.85;
      if (activeTool === 'compress') {
        quality = Math.min(1.0, Math.max(0.2, targetKb / 150));
      }
      dataUrl = canvas.toDataURL('image/jpeg', quality);
    }

    const link = document.createElement('a');
    link.download = `Deepak_Smart_Photo_${activeTool}_${Date.now()}.${format}`;
    link.href = dataUrl;
    link.click();

    // Auto save to My Files
    saveFile({
      title: `Passport Photo (${passportLayout}).${format}`,
      type: 'image',
      size: compressedSize || '95 KB',
      dataUrl: dataUrl,
      category: 'Photo Studio',
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  // Export to PDF
  const handleExportPDF = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    const pdf = new jsPDF({
      orientation: passportLayout === '8-sheet' ? 'portrait' : 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    // Add Title header
    pdf.setFontSize(16);
    pdf.setTextColor(16, 42, 67);
    pdf.text('Deepak Smart App - Passport Photo Studio Sheet', 20, 20);

    pdf.setFontSize(10);
    pdf.setTextColor(100, 100, 100);
    pdf.text('Ready to Print on A4 / 4x6 Photo Glossy Paper', 20, 26);

    // Place image
    pdf.addImage(dataUrl, 'JPEG', 20, 35, 170, 220);

    pdf.save(`Deepak_Passport_Photos_${Date.now()}.pdf`);

    saveFile({
      title: `Passport Photos Sheet.pdf`,
      type: 'pdf',
      size: '220 KB',
      dataUrl: '',
      category: 'Passport Studio',
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto select-none space-y-3.5">
      {/* Studio Header */}
      <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 rounded-3xl p-4 text-white shadow-lg flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white ring-2 ring-white/30 shadow-inner">
            <Camera className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
              AI Photo Studio
            </h2>
            <p className="text-xs text-orange-100 font-medium">
              {language === 'hi'
                ? 'पासपोर्ट फोटो, 8-इन-1 शीट, HD एन्हांसर'
                : 'Passport photos, 8x sheet & signature'}
            </p>
          </div>
        </div>

        <button
          onClick={() => fileInputRef.current?.click()}
          className="px-3 py-1.5 rounded-xl bg-white text-orange-600 font-bold text-xs shadow-md hover:bg-orange-50 transition active:scale-95 flex items-center space-x-1"
        >
          <Upload className="w-3.5 h-3.5" />
          <span>{language === 'hi' ? 'फोटो बदलें' : 'Upload'}</span>
        </button>
      </div>

      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        className="hidden"
        onChange={handleFileUpload}
      />

      {/* Tools Selector Tabs */}
      <div className="grid grid-cols-4 gap-1.5 bg-slate-200/80 dark:bg-slate-800 p-1 rounded-2xl text-[11px] font-bold">
        {[
          { id: 'passport', labelHi: 'पासपोर्ट', labelEn: 'Passport', icon: Camera },
          { id: 'bg-color', labelHi: 'बैकग्राउंड', labelEn: 'BG Color', icon: Palette },
          { id: 'enhancer', labelHi: 'HD सुधार', labelEn: 'Enhance', icon: Sliders },
          { id: 'signature', labelHi: 'हस्ताक्षर', labelEn: 'Signature', icon: FileCheck },
        ].map((tool) => {
          const Icon = tool.icon;
          return (
            <button
              key={tool.id}
              onClick={() => setActiveTool(tool.id as any)}
              className={`py-2 rounded-xl flex flex-col items-center justify-center space-y-0.5 transition ${
                activeTool === tool.id
                  ? 'bg-white dark:bg-slate-900 text-orange-600 dark:text-orange-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{language === 'hi' ? tool.labelHi : tool.labelEn}</span>
            </button>
          );
        })}
      </div>

      {/* Main Canvas Preview Container */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center relative overflow-hidden">
        {/* Canvas */}
        <div className="max-w-full max-h-[340px] overflow-auto flex items-center justify-center p-2 bg-slate-100 dark:bg-slate-800/60 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700">
          <canvas
            ref={canvasRef}
            className="max-h-[300px] w-auto object-contain rounded-lg shadow-md"
          />
        </div>

        {/* Live File Specs */}
        <div className="w-full mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1">
          <span className="font-semibold text-slate-700 dark:text-slate-300">
            {activeTool === 'signature'
              ? '140 x 60 px (Govt Portal Spec)'
              : activeTool === 'passport' && passportLayout === '8-sheet'
              ? '4x6" Sheet (8 Photos)'
              : '35 x 45 mm (Standard Passport)'}
          </span>
          <span className="px-2 py-0.5 rounded-full bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 font-bold text-[10px]">
            Size: {compressedSize || '45 KB'}
          </span>
        </div>
      </div>

      {/* Tool-specific Controls Drawer */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3">
        {activeTool === 'passport' && (
          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-800 dark:text-white block">
              {language === 'hi' ? 'फोटो लेआउट चुनें:' : 'Select Passport Layout:'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: '8-sheet', label: '8 Photos (4x6 Sheet)' },
                { id: '4-grid', label: '4 Photos (Grid)' },
                { id: 'single', label: 'Single (35x45mm)' },
              ].map((layout) => (
                <button
                  key={layout.id}
                  onClick={() => setPassportLayout(layout.id as any)}
                  className={`py-2 px-1 rounded-xl text-[10px] font-bold border transition ${
                    passportLayout === layout.id
                      ? 'bg-orange-500 text-white border-orange-500 shadow-sm'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {layout.label}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                {language === 'hi' ? 'पासपोर्ट ब्लैक बॉर्डर जोड़ें' : 'Add Black Border Line'}
              </span>
              <input
                type="checkbox"
                checked={addBorder}
                onChange={(e) => setAddBorder(e.target.checked)}
                className="w-4 h-4 text-orange-600 rounded"
              />
            </div>
          </div>
        )}

        {activeTool === 'bg-color' && (
          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-800 dark:text-white block">
              {language === 'hi'
                ? 'सरकारी मानक बैकग्राउंड रंग चुनें:'
                : 'Select Official Background Color:'}
            </label>
            <div className="flex items-center space-x-3 overflow-x-auto py-1">
              {[
                { name: 'Studio Blue', color: '#2B50AA' },
                { name: 'Pure White', color: '#FFFFFF' },
                { name: 'Sky Blue', color: '#38BDF8' },
                { name: 'Light Grey', color: '#E2E8F0' },
                { name: 'Pass Red', color: '#DC2626' },
              ].map((c) => (
                <button
                  key={c.color}
                  onClick={() => setBgColor(c.color)}
                  className={`flex flex-col items-center space-y-1 p-1 rounded-xl shrink-0 ${
                    bgColor === c.color ? 'ring-2 ring-orange-500' : ''
                  }`}
                >
                  <div
                    className="w-8 h-8 rounded-full shadow-inner border border-black/20"
                    style={{ backgroundColor: c.color }}
                  ></div>
                  <span className="text-[9px] font-medium text-slate-600 dark:text-slate-400">
                    {c.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {activeTool === 'enhancer' && (
          <div className="space-y-2.5">
            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                <span>{language === 'hi' ? 'चमक (Brightness)' : 'Brightness'}</span>
                <span>{brightness}%</span>
              </div>
              <input
                type="range"
                min="60"
                max="150"
                value={brightness}
                onChange={(e) => setBrightness(Number(e.target.value))}
                className="w-full accent-orange-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                <span>{language === 'hi' ? 'कंट्रास्ट (Contrast / HD)' : 'Contrast / HD'}</span>
                <span>{contrast}%</span>
              </div>
              <input
                type="range"
                min="70"
                max="160"
                value={contrast}
                onChange={(e) => setContrast(Number(e.target.value))}
                className="w-full accent-orange-500"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <button
                onClick={() => {
                  setBrightness(100);
                  setContrast(100);
                  setSaturation(100);
                }}
                className="text-[10px] text-orange-600 dark:text-orange-400 font-bold hover:underline"
              >
                {language === 'hi' ? 'रीसेट करें' : 'Reset Defaults'}
              </button>
              <button
                onClick={() => {
                  setBrightness(115);
                  setContrast(125);
                }}
                className="px-2.5 py-1 rounded-lg bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 text-[10px] font-bold"
              >
                ⚡ 1-Click Auto HD
              </button>
            </div>
          </div>
        )}

        {activeTool === 'signature' && (
          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            <p className="font-semibold text-slate-900 dark:text-white">
              ✍️ {language === 'hi' ? 'हस्ताक्षर क्रॉप और रिसाइज' : 'Signature Resizer'}:
            </p>
            <p className="text-[11px] leading-relaxed">
              यह टूल हस्ताक्षर को सरकारी परीक्षा मानकों (140x60 पिक्सल, 10KB से 20KB के बीच, सफेद पृष्ठभूमि) के अनुसार अपने आप तैयार करता है।
            </p>
          </div>
        )}

        {/* Action Buttons: Download JPG, Export PDF */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-2">
          <button
            onClick={() => handleDownloadImage('jpg')}
            className="py-2.5 px-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-md transition flex items-center justify-center space-x-1.5 active:scale-95"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{language === 'hi' ? 'फोटो सेव करें (JPG)' : 'Save Photo (JPG)'}</span>
          </button>

          <button
            onClick={handleExportPDF}
            className="py-2.5 px-3 rounded-xl bg-[#102A43] hover:bg-[#163554] text-white font-bold text-xs shadow-md transition flex items-center justify-center space-x-1.5 active:scale-95"
          >
            <FileText className="w-3.5 h-3.5 text-orange-400" />
            <span>{language === 'hi' ? 'प्रिंट शीट PDF बनाएं' : 'Export Sheet PDF'}</span>
          </button>
        </div>

        {savedSuccess && (
          <div className="p-2 rounded-xl bg-green-50 text-green-700 text-xs font-semibold flex items-center justify-center space-x-1.5 animate-in fade-in duration-200">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span>
              {language === 'hi'
                ? 'फोटो डाउनलोड हो गई और "माय फाइल्स" में सेव हो गई!'
                : 'Saved and stored in My Files!'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
