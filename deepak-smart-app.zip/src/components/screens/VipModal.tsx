import React, { useState } from 'react';
import { X, Crown, Check, Sparkles, Shield, Zap } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const VipModal: React.FC = () => {
  const { isVipModalOpen, setIsVipModalOpen, user, setUser, language } = useApp();
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('yearly');
  const [success, setSuccess] = useState(false);

  const perks = [
    { hi: 'अनलिमिटेड दीपक AI सवाल (Gemini 3.8 Flash)', en: 'Unlimited Deepak AI queries' },
    { hi: 'पासपोर्ट फोटो 8-इन-1 प्रिंट शीट बिना वॉटरमार्क', en: '8-on-1 Passport Sheets with no watermark' },
    { hi: 'दुकान का लोगो व नाम इनवॉइस और UPI QR में', en: 'Custom shop branding on invoices & QR' },
    { hi: 'स्मार्ट डॉक्यूमेंट स्कैनर व हिंदी ट्रांसलेटर प्रो', en: 'Doc scanner & Hindi translator PRO' },
    { hi: 'प्राथमिकता तकनीकी सहायता (Priority WhatsApp Support)', en: 'Priority WhatsApp Support' },
  ];

  const handleActivate = () => {
    setUser((prev) => ({ ...prev, isVip: true, aiCredits: 9999 }));
    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      setIsVipModalOpen(false);
    }, 1500);
  };

  if (!isVipModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 select-none animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-3xl p-5 shadow-2xl border border-amber-500/40 text-slate-800 dark:text-white relative overflow-hidden">
        {/* Glow */}
        <div className="absolute -top-16 -right-16 w-32 h-32 bg-amber-500/20 rounded-full blur-2xl"></div>

        <button
          onClick={() => setIsVipModalOpen(false)}
          className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mt-2 space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 to-orange-500 text-white flex items-center justify-center mx-auto shadow-lg shadow-orange-500/30">
            <Crown className="w-8 h-8" />
          </div>

          <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
            Deepak Smart VIP Membership
          </h3>
          <p className="text-xs text-slate-500">
            {language === 'hi'
              ? 'साइबर कैफे व सीएससी सेंटर संचालकों के लिए विशेष प्रो प्लान'
              : 'Exclusive Pro plan for CSC operators & professionals'}
          </p>
        </div>

        {/* Pricing selector */}
        <div className="grid grid-cols-2 gap-2 my-4">
          <div
            onClick={() => setSelectedPlan('monthly')}
            className={`p-3 rounded-2xl border text-center cursor-pointer transition ${
              selectedPlan === 'monthly'
                ? 'border-orange-500 bg-orange-50 dark:bg-slate-800'
                : 'border-slate-200 dark:border-slate-800'
            }`}
          >
            <span className="text-[10px] font-bold text-slate-500 block">मासिक (Monthly)</span>
            <span className="text-lg font-black text-slate-900 dark:text-white">₹99</span>
            <span className="text-[9px] text-slate-400 block">/ प्रति माह</span>
          </div>

          <div
            onClick={() => setSelectedPlan('yearly')}
            className={`p-3 rounded-2xl border text-center cursor-pointer relative transition ${
              selectedPlan === 'yearly'
                ? 'border-amber-500 bg-amber-50 dark:bg-slate-800 ring-2 ring-amber-400'
                : 'border-slate-200 dark:border-slate-800'
            }`}
          >
            <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-amber-500 text-white text-[8px] font-black px-2 py-0.5 rounded-full uppercase">
              Save 60%
            </span>
            <span className="text-[10px] font-bold text-slate-500 block">वार्षिक (Yearly)</span>
            <span className="text-lg font-black text-amber-600">₹499</span>
            <span className="text-[9px] text-slate-400 block">/ पूरा 1 साल</span>
          </div>
        </div>

        {/* Perks */}
        <div className="space-y-2 mb-4 text-xs">
          {perks.map((p, i) => (
            <div key={i} className="flex items-center space-x-2 text-slate-700 dark:text-slate-300">
              <Check className="w-4 h-4 text-green-500 shrink-0" />
              <span className="text-[11px] font-medium leading-tight">
                {language === 'hi' ? p.hi : p.en}
              </span>
            </div>
          ))}
        </div>

        {success ? (
          <div className="p-2.5 rounded-xl bg-green-50 text-green-700 text-xs font-bold text-center">
            ✓ VIP एक्टिवेट हो गया है!
          </div>
        ) : (
          <button
            onClick={handleActivate}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-extrabold text-xs shadow-lg transition active:scale-95 flex items-center justify-center space-x-1.5"
          >
            <Zap className="w-4 h-4" />
            <span>
              {user.isVip
                ? (language === 'hi' ? 'VIP पहले से एक्टिव है (नवीनीकरण)' : 'VIP Already Active')
                : (language === 'hi' ? 'तुरंत VIP एक्टिवेट करें' : 'Activate VIP Now')}
            </span>
          </button>
        )}
      </div>
    </div>
  );
};
