import React, { useState } from 'react';
import {
  Building,
  CheckCircle2,
  Clock,
  ExternalLink,
  FileCheck,
  Search,
  ShieldAlert,
  ArrowRight,
  Info,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { INITIAL_CSC_SERVICES } from '../../data/mockData';
import { CSCService } from '../../types';

export const CSCServicesScreen: React.FC = () => {
  const { language } = useApp();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedServiceId, setExpandedServiceId] = useState<string | null>('csc-aadhaar');
  const [checkedDocs, setCheckedDocs] = useState<Record<string, boolean>>({});

  const filteredServices = INITIAL_CSC_SERVICES.filter((svc) => {
    const title = language === 'hi' ? svc.titleHi : svc.titleEn;
    const desc = language === 'hi' ? svc.descriptionHi : svc.descriptionEn;
    const matchesSearch =
      title.toLowerCase().includes(search.toLowerCase()) ||
      desc.toLowerCase().includes(search.toLowerCase());
    const matchesCat = selectedCategory === 'all' || svc.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const toggleDoc = (key: string) => {
    setCheckedDocs((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto select-none space-y-3.5">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 rounded-3xl p-4 text-white shadow-lg flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white ring-2 ring-white/30 shadow-inner">
            <Building className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold tracking-tight">
              CSC Digital Seva Portal
            </h2>
            <p className="text-xs text-blue-100 font-medium">
              {language === 'hi'
                ? 'सरकारी योजना, आधार, पैन, RTPS गाइड'
                : 'Govt schemes, Aadhaar, PAN & RTPS guide'}
            </p>
          </div>
        </div>
      </div>

      {/* Official Assistance Disclaimer Notice */}
      <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-900/60 text-amber-900 dark:text-amber-200 flex items-start space-x-2.5 text-xs">
        <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-bold">
            {language === 'hi' ? 'महत्वपूर्ण सूचना (Disclaimer):' : 'Important Notice:'}
          </span>{' '}
          {language === 'hi'
            ? 'दीपक स्मार्ट ऐप एक डिजिटल सहायता टूल है। हम केवल आधिकारिक सत्यापित सरकारी पोर्टल्स के मार्गदर्शन एवं सीधे लिंक्स प्रदान करते हैं। संवेदनशील डेटा कभी साझा न करें।'
            : 'Deepak Smart App provides digital facilitation & verified links to official portals. We do not process sensitive data directly.'}
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={
            language === 'hi' ? 'सेवा खोजें (आधार, पैन, जाति प्रमाण पत्र...)' : 'Search services...'
          }
          className="w-full bg-white dark:bg-slate-900 text-slate-900 dark:text-white pl-10 pr-4 py-2.5 rounded-2xl text-xs border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
        />
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar py-0.5">
        {[
          { id: 'all', labelHi: 'सभी सेवाएं', labelEn: 'All' },
          { id: 'identity', labelHi: 'पहचान पत्र (Aadhaar/PAN)', labelEn: 'Identity' },
          { id: 'certificates', labelHi: 'RTPS प्रमाण पत्र', labelEn: 'Certificates' },
          { id: 'welfare', labelHi: 'कल्याणकारी योजनाएं', labelEn: 'Welfare' },
        ].map((c) => (
          <button
            key={c.id}
            onClick={() => setSelectedCategory(c.id)}
            className={`py-1.5 px-3 rounded-xl text-[11px] font-bold shrink-0 transition ${
              selectedCategory === c.id
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
            }`}
          >
            {language === 'hi' ? c.labelHi : c.labelEn}
          </button>
        ))}
      </div>

      {/* Services List */}
      <div className="space-y-3">
        {filteredServices.map((svc) => {
          const isExpanded = expandedServiceId === svc.id;
          const title = language === 'hi' ? svc.titleHi : svc.titleEn;
          const desc = language === 'hi' ? svc.descriptionHi : svc.descriptionEn;
          const docs = language === 'hi' ? svc.requiredDocsHi : svc.requiredDocsEn;
          const steps = language === 'hi' ? svc.stepsHi : svc.stepsEn;

          return (
            <div
              key={svc.id}
              className="bg-white dark:bg-slate-900 rounded-3xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 transition overflow-hidden"
            >
              {/* Service Header Row */}
              <div
                onClick={() => setExpandedServiceId(isExpanded ? null : svc.id)}
                className="flex items-start justify-between cursor-pointer"
              >
                <div className="space-y-1 pr-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 uppercase">
                      {svc.category}
                    </span>
                    <span className="text-[10px] text-slate-400 flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{svc.estimatedDays}</span>
                    </span>
                  </div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                    {title}
                  </h3>
                  <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                    {desc}
                  </p>
                </div>

                <div className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </div>

              {/* Expanded Details: Docs Checklist + Steps + Official Portal Link */}
              {isExpanded && (
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3.5 animate-in fade-in duration-150">
                  {/* Fee & Processing */}
                  <div className="grid grid-cols-2 gap-2 text-[11px] p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60">
                    <div>
                      <span className="text-slate-400 block font-medium">सरकारी शुल्क (Fee):</span>
                      <span className="font-bold text-slate-800 dark:text-white">{svc.govtFee}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-medium">कार्य अवधि (Time):</span>
                      <span className="font-bold text-slate-800 dark:text-white">{svc.estimatedDays}</span>
                    </div>
                  </div>

                  {/* Document Checklist with Interactive Checkboxes */}
                  <div>
                    <h4 className="text-[11px] font-bold text-slate-800 dark:text-white uppercase tracking-wider mb-2 flex items-center space-x-1">
                      <FileCheck className="w-3.5 h-3.5 text-blue-500" />
                      <span>
                        {language === 'hi' ? 'ज़रूरी दस्तावेज़ चेकलिस्ट (Tick when ready):' : 'Required Documents Checklist:'}
                      </span>
                    </h4>
                    <div className="space-y-1.5">
                      {docs.map((doc, idx) => {
                        const key = `${svc.id}_doc_${idx}`;
                        const isDone = !!checkedDocs[key];
                        return (
                          <div
                            key={idx}
                            onClick={() => toggleDoc(key)}
                            className={`p-2 rounded-xl border text-xs flex items-center space-x-2 cursor-pointer transition ${
                              isDone
                                ? 'bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800 text-green-800 dark:text-green-300'
                                : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isDone}
                              onChange={() => {}}
                              className="w-3.5 h-3.5 text-green-600 rounded pointer-events-none"
                            />
                            <span className="text-[11px] leading-tight">{doc}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Step-by-step guidance */}
                  <div>
                    <h4 className="text-[11px] font-bold text-slate-800 dark:text-white uppercase tracking-wider mb-2 flex items-center space-x-1">
                      <Info className="w-3.5 h-3.5 text-orange-500" />
                      <span>{language === 'hi' ? 'आवेदन कैसे करें (Steps):' : 'Application Process:'}</span>
                    </h4>
                    <ol className="space-y-1.5 pl-4 list-decimal text-[11px] text-slate-600 dark:text-slate-300">
                      {steps.map((st, i) => (
                        <li key={i} className="leading-relaxed">
                          {st}
                        </li>
                      ))}
                    </ol>
                  </div>

                  {/* Official Portal Direct Button */}
                  <a
                    href={svc.officialPortal}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md transition flex items-center justify-center space-x-1.5"
                  >
                    <span>
                      {language === 'hi'
                        ? `आधिकारिक पोर्टल पर जाएं (${svc.officialPortalName})`
                        : `Open Official Portal (${svc.officialPortalName})`}
                    </span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
