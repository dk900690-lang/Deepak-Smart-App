import React, { useState, useEffect } from 'react';
import { Mic, MicOff, X, Sparkles, ArrowRight, Volume2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const VoiceActionModal: React.FC = () => {
  const { isVoiceModalOpen, setIsVoiceModalOpen, setCurrentTab, setServiceSubTab, language } = useApp();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [recognition, setRecognition] = useState<any>(null);

  const sampleCommands = [
    { text: 'पासपोर्ट साइज फोटो बनाओ', en: 'Make passport size photo', action: 'photo' },
    { text: 'सरकारी नौकरी अपडेट दिखाओ', en: 'Show govt job updates', action: 'jobs' },
    { text: 'बैंक मैनेजर को आवेदन पत्र लिखो', en: 'Write letter to bank manager', action: 'write' },
    { text: 'दस्तावेज़ को पीडीएफ में बदलो', en: 'Convert document to PDF', action: 'pdf' },
    { text: 'राशन कार्ड या आधार सेवा खोलो', en: 'Open Aadhaar or Ration card', action: 'csc' },
    { text: 'दुकान का बिल / इनवॉइस बनाओ', en: 'Create shop invoice', action: 'invoice' },
  ];

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const reco = new SpeechRecognition();
        reco.continuous = false;
        reco.interimResults = true;
        reco.lang = language === 'hi' ? 'hi-IN' : 'en-IN';

        reco.onstart = () => {
          setIsListening(true);
          setStatusMessage(language === 'hi' ? 'सुन रहा हूँ... बोलिए' : 'Listening... Speak now');
        };

        reco.onresult = (event: any) => {
          const current = event.resultIndex;
          const text = event.results[current][0].transcript;
          setTranscript(text);
        };

        reco.onerror = (event: any) => {
          console.warn('Speech recognition error:', event.error);
          setIsListening(false);
          setStatusMessage(
            language === 'hi'
              ? 'माइक से आवाज़ नहीं मिली। नीचे दिए गए किसी भी सुझाव पर क्लिक करें।'
              : 'Microphone not captured. Click any preset below.'
          );
        };

        reco.onend = () => {
          setIsListening(false);
        };

        setRecognition(reco);
      }
    }
  }, [language]);

  const startListening = () => {
    setTranscript('');
    setStatusMessage('');
    if (recognition) {
      try {
        recognition.start();
      } catch (e) {
        recognition.stop();
        setTimeout(() => recognition.start(), 200);
      }
    } else {
      setStatusMessage(
        language === 'hi'
          ? 'आपके ब्राउज़र में ऑटो-माइक समर्थित नहीं है। नीचे दिया गया कोई भी आदेश चुनें:'
          : 'Microphone direct access not supported. Click a command below:'
      );
    }
  };

  const stopListening = () => {
    if (recognition) {
      recognition.stop();
    }
    setIsListening(false);
  };

  const executeAction = async (commandText: string) => {
    setStatusMessage(language === 'hi' ? 'आदेश प्रोसेस किया जा रहा है...' : 'Processing command...');

    // Call server voice action endpoint
    try {
      const res = await fetch('/api/ai/voice-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: commandText }),
      });
      const data = await res.json();

      // Speak feedback
      speakHindi(data.message);

      setTimeout(() => {
        setIsVoiceModalOpen(false);
        if (data.target === 'photo-studio') {
          setCurrentTab('services');
          setServiceSubTab('photo');
        } else if (data.target === 'pdf-studio') {
          setCurrentTab('services');
          setServiceSubTab('pdf');
        } else if (data.target === 'jobs') {
          setCurrentTab('services');
          setServiceSubTab('jobs');
        } else if (data.target === 'csc-services') {
          setCurrentTab('services');
          setServiceSubTab('csc');
        } else if (data.target === 'business-tools') {
          setCurrentTab('services');
          setServiceSubTab('business');
        } else if (data.target === 'ai-assistant') {
          setCurrentTab('ai-assistant');
        } else if (data.target === 'my-files') {
          setCurrentTab('my-files');
        } else {
          setCurrentTab('home');
        }
      }, 700);
    } catch (e) {
      // Direct local fallback
      const text = commandText.toLowerCase();
      if (text.includes('photo') || text.includes('फोटो') || text.includes('passport')) {
        setCurrentTab('services');
        setServiceSubTab('photo');
      } else if (text.includes('pdf') || text.includes('दस्तावेज')) {
        setCurrentTab('services');
        setServiceSubTab('pdf');
      } else if (text.includes('job') || text.includes('नौकरी')) {
        setCurrentTab('services');
        setServiceSubTab('jobs');
      } else if (text.includes('bill') || text.includes('invoice') || text.includes('इनवॉइस')) {
        setCurrentTab('services');
        setServiceSubTab('business');
      } else {
        setCurrentTab('ai-assistant');
      }
      setIsVoiceModalOpen(false);
    }
  };

  const speakHindi = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
      utterance.rate = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  if (!isVoiceModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-3xl p-6 shadow-2xl border border-orange-500/30 text-slate-800 dark:text-white relative overflow-hidden">
        {/* Glow decoration */}
        <div className="absolute -top-16 -right-16 w-32 h-32 bg-orange-500/20 rounded-full blur-2xl pointer-events-none"></div>

        {/* Close Button */}
        <button
          onClick={() => {
            stopListening();
            setIsVoiceModalOpen(false);
          }}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mt-2">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 text-xs font-bold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Smart Voice-to-Action</span>
          </div>

          <h3 className="text-lg font-bold">
            {language === 'hi' ? 'बोलकर काम करवाएं' : 'Speak to Control App'}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {language === 'hi'
              ? 'हिंदी या इंग्लिश में बोलें, दीपक स्मार्ट ऐप तुरंत वह टूल खोलेगा।'
              : 'Speak in Hindi or English, the app will execute your action.'}
          </p>

          {/* Big Animated Mic Button */}
          <div className="my-6 flex flex-col items-center justify-center">
            <div className="relative">
              {isListening && (
                <>
                  <div className="absolute inset-0 rounded-full bg-orange-500 animate-ping opacity-40"></div>
                  <div className="absolute -inset-4 rounded-full bg-orange-400/20 animate-pulse"></div>
                </>
              )}
              <button
                onClick={isListening ? stopListening : startListening}
                className={`w-20 h-20 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 ${
                  isListening
                    ? 'bg-red-500 text-white shadow-red-500/50'
                    : 'bg-gradient-to-tr from-orange-500 to-amber-500 text-white shadow-orange-500/40 hover:scale-105'
                }`}
              >
                {isListening ? <MicOff className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
              </button>
            </div>

            <p className="text-xs font-semibold mt-3 text-orange-600 dark:text-orange-400">
              {isListening
                ? (language === 'hi' ? 'सुन रहा हूँ... बोलिए' : 'Listening... Speak now')
                : (language === 'hi' ? 'माइक पर टैप करके बोलें' : 'Tap mic to speak')}
            </p>
          </div>

          {/* Transcript / Result Box */}
          {transcript && (
            <div className="p-3 bg-orange-50 dark:bg-slate-800/80 rounded-xl border border-orange-200 dark:border-slate-700 mb-4 text-left">
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                {language === 'hi' ? 'सुनाई दिया:' : 'Heard:'}
              </span>
              <p className="text-sm font-semibold text-slate-800 dark:text-white mt-0.5">
                "{transcript}"
              </p>
              <button
                onClick={() => executeAction(transcript)}
                className="mt-2 w-full py-1.5 px-3 bg-orange-500 hover:bg-orange-600 text-white rounded-lg text-xs font-bold flex items-center justify-center space-x-1 shadow"
              >
                <span>{language === 'hi' ? 'यह कार्य शुरू करें' : 'Execute Command'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {statusMessage && !transcript && (
            <p className="text-xs text-slate-500 italic mb-4">{statusMessage}</p>
          )}

          {/* Quick Command Suggestions */}
          <div className="text-left mt-2">
            <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block mb-2">
              {language === 'hi' ? 'या इनपर क्लिक करके देखें:' : 'Or tap any command below:'}
            </span>
            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
              {sampleCommands.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    const text = language === 'hi' ? item.text : item.en;
                    setTranscript(text);
                    executeAction(text);
                  }}
                  className="w-full text-left p-2 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-orange-50 dark:hover:bg-slate-700/80 border border-slate-200/60 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 flex items-center justify-between group transition"
                >
                  <span className="truncate pr-2 font-medium">
                    "{language === 'hi' ? item.text : item.en}"
                  </span>
                  <Volume2 className="w-3.5 h-3.5 text-orange-500 shrink-0 opacity-70 group-hover:opacity-100" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
