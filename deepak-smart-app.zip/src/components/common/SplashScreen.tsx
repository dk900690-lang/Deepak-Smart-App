import React, { useEffect, useState } from 'react';
import { Sparkles } from 'lucide-react';

export const SplashScreen: React.FC<{ onFinish: () => void }> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onFinish, 300);
          return 100;
        }
        return prev + 20;
      });
    }, 150);

    return () => clearInterval(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-b from-[#102A43] via-[#0C2135] to-[#081726] text-white flex flex-col items-center justify-between p-8 select-none">
      {/* Top Tag */}
      <div className="w-full flex justify-end">
        <span className="text-[10px] tracking-widest text-orange-400 font-bold uppercase bg-orange-500/10 px-3 py-1 rounded-full border border-orange-500/20">
          Smart Bharat Edition
        </span>
      </div>

      {/* Main Logo & Branding */}
      <div className="flex flex-col items-center text-center my-auto animate-in fade-in zoom-in-95 duration-500">
        <div className="relative mb-6">
          <div className="absolute -inset-4 bg-orange-500/30 rounded-3xl blur-xl animate-pulse"></div>
          <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-tr from-amber-500 via-orange-500 to-amber-600 p-1 shadow-2xl shadow-orange-500/50 flex items-center justify-center">
            <div className="w-full h-full bg-[#102A43] rounded-[22px] flex items-center justify-center relative overflow-hidden">
              <span className="text-5xl font-black bg-gradient-to-br from-amber-300 via-orange-400 to-yellow-200 bg-clip-text text-transparent">
                D
              </span>
              <div className="absolute bottom-0 w-full h-2 bg-gradient-to-r from-orange-500 via-white to-green-600"></div>
            </div>
          </div>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          Deepak <span className="text-orange-400">Smart App</span>
        </h1>
        <p className="text-sm font-semibold text-orange-200/90 mt-2 tracking-wide font-['Hind']">
          "आपका अपना डिजिटल स्मार्ट साथी"
        </p>
        <p className="text-xs text-slate-400 mt-1">
          AI • CSC Services • Photo Studio • PDF • Jobs • Business
        </p>
      </div>

      {/* Bottom Loading Bar */}
      <div className="w-full max-w-xs flex flex-col items-center space-y-3 pb-4">
        <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-amber-400 via-orange-500 to-green-500 rounded-full transition-all duration-200"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        <div className="flex items-center space-x-1.5 text-xs text-orange-300/80">
          <Sparkles className="w-3.5 h-3.5 animate-spin" />
          <span>डिजिटल सेवाएं लोड हो रही हैं...</span>
        </div>
      </div>
    </div>
  );
};
