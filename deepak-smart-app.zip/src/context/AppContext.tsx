import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, ThemeMode, MainTab, ServiceSubTab, UserProfile, SavedFile, NotificationItem, JobItem } from '../types';
import { INITIAL_JOBS } from '../data/mockData';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  isAndroidFrame: boolean;
  setIsAndroidFrame: (val: boolean | ((prev: boolean) => boolean)) => void;
  currentTab: MainTab;
  setCurrentTab: (tab: MainTab) => void;
  serviceSubTab: ServiceSubTab;
  setServiceSubTab: (sub: ServiceSubTab) => void;
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  savedFiles: SavedFile[];
  saveFile: (file: Omit<SavedFile, 'id' | 'date'>) => void;
  deleteFile: (id: string) => void;
  bookmarkedJobs: string[];
  toggleBookmarkJob: (jobId: string) => void;
  notifications: NotificationItem[];
  markNotificationRead: (id: string) => void;
  addNotification: (notif: Omit<NotificationItem, 'id' | 'date' | 'read'>) => void;
  isVoiceModalOpen: boolean;
  setIsVoiceModalOpen: (open: boolean) => void;
  isAdminModalOpen: boolean;
  setIsAdminModalOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isVipModalOpen: boolean;
  setIsVipModalOpen: (open: boolean) => void;
  isExportModalOpen: boolean;
  setIsExportModalOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  deductCredit: () => boolean;
  addCredits: (amount: number) => void;
  jobsList: JobItem[];
  addJobNotification: (job: JobItem) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('deepak_app_lang') as Language) || 'hi';
  });

  const [theme, setTheme] = useState<ThemeMode>(() => {
    return (localStorage.getItem('deepak_app_theme') as ThemeMode) || 'light';
  });

  const [isAndroidFrame, setIsAndroidFrame] = useState<boolean>(() => {
    return localStorage.getItem('deepak_android_frame') !== 'false';
  });

  const [currentTab, setCurrentTab] = useState<MainTab>('home');
  const [serviceSubTab, setServiceSubTab] = useState<ServiceSubTab>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('deepak_app_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return {
      id: 'usr_88291',
      name: 'Deepak Kumar',
      phone: '+91 98765 43210',
      email: 'deepakgayacsc@gmail.com',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      isLoggedIn: true,
      isVip: true,
      aiCredits: 100,
      role: 'admin',
      joinedDate: 'November 2026',
      shopName: 'Deepak Digital CSC Seva Kendra, Gaya',
      upiId: 'deepakgayacsc@okaxis',
    };
  });

  const [savedFiles, setSavedFiles] = useState<SavedFile[]>(() => {
    const saved = localStorage.getItem('deepak_saved_files');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return [
      {
        id: 'file-demo-1',
        title: 'Passport Photo 8-on-1 Sheet.pdf',
        type: 'pdf',
        date: '2026-11-07',
        size: '142 KB',
        dataUrl: '',
        category: 'Passport Studio',
      },
      {
        id: 'file-demo-2',
        title: 'GST Invoice #INV-2026-001.pdf',
        type: 'invoice',
        date: '2026-11-06',
        size: '88 KB',
        dataUrl: '',
        category: 'Business Billing',
      },
    ];
  });

  const [bookmarkedJobs, setBookmarkedJobs] = useState<string[]>(() => {
    const saved = localStorage.getItem('deepak_bookmarks');
    return saved ? JSON.parse(saved) : ['job-1', 'job-3'];
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-1',
      title: 'बिहार पुलिस सिपाही भर्ती 2026',
      message: 'ऑनलाइन आवेदन फॉर्म जमा करने की अंतिम तिथि 15 दिसंबर है। समय रहते आवेदन करें।',
      date: '10 मिनट पहले',
      read: false,
      type: 'alert',
      linkTab: 'services',
    },
    {
      id: 'notif-2',
      title: 'दीपक स्मार्ट ऐप में स्वागत है!',
      message: 'आपका अपना डिजिटल साथी अब पूरी तरह एक्टिव है। सभी टूल्स का आनंद लें।',
      date: 'आज, 09:00 AM',
      read: false,
      type: 'success',
      linkTab: 'home',
    },
  ]);

  const [jobsList, setJobsList] = useState<JobItem[]>(INITIAL_JOBS);

  // Modals
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isVipModalOpen, setIsVipModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  // Persistence
  useEffect(() => {
    localStorage.setItem('deepak_app_lang', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('deepak_app_theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('deepak_android_frame', String(isAndroidFrame));
  }, [isAndroidFrame]);

  useEffect(() => {
    localStorage.setItem('deepak_app_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('deepak_saved_files', JSON.stringify(savedFiles));
  }, [savedFiles]);

  useEffect(() => {
    localStorage.setItem('deepak_bookmarks', JSON.stringify(bookmarkedJobs));
  }, [bookmarkedJobs]);

  const saveFile = (file: Omit<SavedFile, 'id' | 'date'>) => {
    const newFile: SavedFile = {
      ...file,
      id: `file_${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
    };
    setSavedFiles((prev) => [newFile, ...prev]);
  };

  const deleteFile = (id: string) => {
    setSavedFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const toggleBookmarkJob = (jobId: string) => {
    setBookmarkedJobs((prev) =>
      prev.includes(jobId) ? prev.filter((id) => id !== jobId) : [...prev, jobId]
    );
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const addNotification = (notif: Omit<NotificationItem, 'id' | 'date' | 'read'>) => {
    const newN: NotificationItem = {
      ...notif,
      id: `n_${Date.now()}`,
      date: 'अभी-अभी',
      read: false,
    };
    setNotifications((prev) => [newN, ...prev]);
  };

  const deductCredit = (): boolean => {
    if (user.isVip) return true; // VIP has unlimited credits
    if (user.aiCredits <= 0) return false;
    setUser((prev) => ({ ...prev, aiCredits: prev.aiCredits - 1 }));
    return true;
  };

  const addCredits = (amount: number) => {
    setUser((prev) => ({ ...prev, aiCredits: prev.aiCredits + amount }));
  };

  const addJobNotification = (newJob: JobItem) => {
    setJobsList((prev) => [newJob, ...prev]);
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        theme,
        setTheme,
        isAndroidFrame,
        setIsAndroidFrame,
        currentTab,
        setCurrentTab,
        serviceSubTab,
        setServiceSubTab,
        user,
        setUser,
        savedFiles,
        saveFile,
        deleteFile,
        bookmarkedJobs,
        toggleBookmarkJob,
        notifications,
        markNotificationRead,
        addNotification,
        isVoiceModalOpen,
        setIsVoiceModalOpen,
        isAdminModalOpen,
        setIsAdminModalOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isVipModalOpen,
        setIsVipModalOpen,
        isExportModalOpen,
        setIsExportModalOpen,
        searchQuery,
        setSearchQuery,
        deductCredit,
        addCredits,
        jobsList,
        addJobNotification,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
