import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '30mb' }));
app.use(express.urlencoded({ extended: true, limit: '30mb' }));

// Initialize GoogleGenAI server-side with required telemetry header
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.error('Failed to initialize GoogleGenAI client:', err);
  }
}

// In-memory data store for community/admin updates
let jobNotifications = [
  {
    id: 'job-1',
    title: 'Bihar Police Constable Recruitment 2026',
    department: 'CSBC Bihar',
    totalPosts: '21,391',
    qualification: '10+2 (Inter) Pass',
    ageLimit: '18 - 25 Years',
    lastDate: '2026-12-15',
    category: 'State (Bihar)',
    salary: 'Level-3 (₹21,700 - ₹69,100)',
    officialUrl: 'https://csbc.bih.nic.in',
    status: 'Active',
    featured: true,
  },
  {
    id: 'job-2',
    title: 'Railway RRB ALP & Technician Exam 2026',
    department: 'Railway Recruitment Board',
    totalPosts: '18,799',
    qualification: 'Matriculation + ITI / Diploma',
    ageLimit: '18 - 30 Years',
    lastDate: '2026-11-30',
    category: 'Central',
    salary: '₹19,900 - ₹35,400',
    officialUrl: 'https://indianrailways.gov.in',
    status: 'Active',
    featured: true,
  },
  {
    id: 'job-3',
    title: 'BSSC Inter Level Combined Competitive Exam',
    department: 'Bihar Staff Selection Commission',
    totalPosts: '12,199',
    qualification: 'Intermediate (12th Pass)',
    ageLimit: '18 - 37 Years',
    lastDate: '2026-12-20',
    category: 'State (Bihar)',
    salary: 'Level-2 to Level-4',
    officialUrl: 'https://bssc.bihar.gov.in',
    status: 'Active',
    featured: true,
  },
  {
    id: 'job-4',
    title: 'SSC Combined Graduate Level (CGL) 2026',
    department: 'Staff Selection Commission',
    totalPosts: '17,727',
    qualification: 'Bachelor’s Degree in any discipline',
    ageLimit: '18 - 32 Years',
    lastDate: '2026-12-05',
    category: 'Central',
    salary: 'Level 4 to Level 8',
    officialUrl: 'https://ssc.gov.in',
    status: 'Active',
    featured: false,
  },
  {
    id: 'job-5',
    title: 'Bihar Revenue Officer & Amin Vacancy',
    department: 'Department of Revenue & Land Reforms Bihar',
    totalPosts: '10,101',
    qualification: 'Diploma / Graduate',
    ageLimit: '18 - 37 Years',
    lastDate: '2026-11-28',
    category: 'State (Bihar)',
    salary: '₹25,000 - ₹31,000 fixed + allowances',
    officialUrl: 'https://state.bihar.gov.in/revenue',
    status: 'Active',
    featured: false,
  },
];

let adminAnnouncements = [
  {
    id: 'notif-1',
    title: 'RTPS Bihar Service Update',
    message: 'जाति, आय, निवास प्रमाण पत्र 7 दिनों के भीतर ई-डिस्ट्रिक्ट पोर्टल से डाउनलोड करें।',
    date: 'आज, 10:30 AM',
    type: 'alert',
  },
  {
    id: 'notif-2',
    title: 'Deepak Smart App v2.5 Updated',
    message: 'नया पासपोर्ट फोटो 8-ऑन-1 शीट मेकर और स्मार्ट डॉक्युमेंट स्कैनर टूल उपलब्ध है!',
    date: 'कल',
    type: 'success',
  },
];

// Helper to sanitize Gemini response
const SYSTEM_INSTRUCTION_DEEPAK_AI = `
You are "Deepak AI" (दीपक एआई), the intelligent digital assistant of "Deepak Smart App" (दीपक स्मार्ट ऐप).
Tagline: "आपका अपना डिजिटल स्मार्ट साथी".
Your primary identity and audience:
- Indian citizens, cyber cafe / CSC Digital Seva Kendra operators, students, job aspirants, and small business owners.
- You specialize in Indian government documents (Aadhaar, PAN, Ration card, RTPS caste/income/residence, e-Shram, Voter ID), Sarkari job forms, scholarship applications, photo/PDF instructions, and digital literacy.
- Communication style: Highly respectful, warm, clear, structured, and easy to understand in simple Hindi (or English if the user asks in English). Use bullet points and clear steps.
- When explaining complex government or technical procedures, explain them step-by-step so anyone can understand easily.
`;

// 1. AI Chat Endpoint (Supports text, image understanding, document OCR)
app.post('/api/ai/chat', async (req, res) => {
  try {
    const { message, history, imageBase64, mimeType } = req.body;

    if (!message && !imageBase64) {
      return res.status(400).json({ error: 'Message or image required' });
    }

    if (!ai) {
      // Fallback response if API key is not configured
      return res.json({
        reply: `नमस्ते! मैं दीपक एआई (Deepak AI) हूँ। मुझे आपका सवाल मिला: "${message || 'दस्तावेज़/फोटो'}"।\n\nदीपक स्मार्ट ऐप आपकी डिजिटल सेवाओं, फोटो स्टूडियो, सरकारी फॉर्म और जॉब्स में पूरी मदद करता है। कृपया सेटिंग्स में सुनिश्चित करें कि जेमिनी एपीआई की कनेक्टेड है।`,
        source: 'fallback',
      });
    }

    // Build contents
    const contents: any[] = [];

    // Add prior history if provided
    if (Array.isArray(history) && history.length > 0) {
      for (const h of history.slice(-6)) {
        contents.push({
          role: h.role === 'user' ? 'user' : 'model',
          parts: [{ text: h.text }],
        });
      }
    }

    const currentParts: any[] = [];
    if (imageBase64) {
      // Clean data url prefix if present
      const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, '');
      currentParts.push({
        inlineData: {
          mimeType: mimeType || 'image/jpeg',
          data: cleanBase64,
        },
      });
    }

    currentParts.push({
      text: message || 'कृपया इस दस्तावेज़/फोटो का विश्लेषण करें और सरल हिंदी में बताएं कि इसमें क्या लिखा है और आगे क्या करना होगा।',
    });

    contents.push({
      role: 'user',
      parts: currentParts,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION_DEEPAK_AI,
      },
    });

    const reply = response.text || 'दीपक एआई ने उत्तर तैयार नहीं कर पाया। कृपया दोबारा प्रयास करें।';
    return res.json({ reply, source: 'gemini' });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    return res.status(500).json({
      error: error.message || 'Error processing AI request',
      reply: 'नमस्ते, सर्वर से संपर्क करने में समस्या आई। कृपया थोड़ी देर बाद पुनः प्रयास करें या प्रश्न दोहराएं।',
    });
  }
});

// 2. AI Content / Letter / Application Writer
app.post('/api/ai/write', async (req, res) => {
  try {
    const { type, topic, recipient, language, keyPoints } = req.body;

    const prompt = `
Task: Write a high quality ${type || 'Application/Letter'} in ${language || 'Hindi'}.
Topic: ${topic || 'General Request'}
Recipient / Authority: ${recipient || 'Concerned Officer / Authority'}
Key points to include: ${keyPoints || 'Standard formal format'}

Requirements:
- Professional, authentic Indian official format (सेवा में / To, महोदय / Respected Sir, Subject, Body, Prarthi / Regards, Date, Place, Signature space).
- Ready to print or copy directly.
- Flawless grammar and courteous tone.
`;

    if (!ai) {
      return res.json({
        content: `सेवा में,\nश्रीमान शाखा प्रबंधक महोदय,\n[शाखा का नाम एवं पता]\n\nविषय: ${topic || 'आवेदन पत्र'}\n\nमहोदय,\nसविनय निवेदन है कि प्रार्थी आपके बैंक का खाताधारक है... (दीपक एआई ड्राफ्ट नमूना)\n\nधन्यवाद,\nभवदीय,\n[आपका नाम]\nमोबाइल: [मोबाइल नंबर]`,
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are an expert Indian official document writer, legal clerk, and content creator.',
      },
    });

    return res.json({ content: response.text });
  } catch (err: any) {
    console.error('Write API Error:', err);
    return res.status(500).json({ error: err.message });
  }
});

// 3. Document Explanation & Summarizer (Smart Bharat Mode)
app.post('/api/ai/document-explain', async (req, res) => {
  try {
    const { text, imageBase64 } = req.body;

    if (!ai) {
      return res.json({
        summary: 'दस्तावेज़ का सरल सारांश: यह एक आधिकारिक सरकारी सूचना है। कृपया निर्धारित अंतिम तिथि से पहले अपने सभी मूल प्रमाण पत्र संलग्न कर आवेदन जमा करें।',
      });
    }

    const parts: any[] = [];
    if (imageBase64) {
      const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, '');
      parts.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: cleanBase64,
        },
      });
    }

    parts.push({
      text: `यह सरकारी नोटिस / दस्तावेज़ है:\n${text || ''}\n\nकृपया इसे बहुत ही सरल और स्पष्ट देहाती/शहरी हिंदी में समझाएं:
1. यह दस्तावेज़ क्या है?
2. आम नागरिक / छात्र के लिए इसमें क्या मुख्य बात है?
3. क्या कोई महत्वपूर्ण तारीख (Last Date) या फीस है?
4. इसके लिए कौन-कौन से ज़रूरी कागज़ (Documents) लगेंगे?
5. अगला कदम (Next Step) क्या उठाना चाहिए?`,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: { parts },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION_DEEPAK_AI,
      },
    });

    return res.json({ summary: response.text });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 4. Voice-to-Action Interpreter
app.post('/api/ai/voice-action', async (req, res) => {
  const { command } = req.body;
  const cmd = (command || '').toLowerCase().trim();

  // Intelligent route mapping based on Hindi/English voice commands
  let target = 'home';
  let message = 'होम स्क्रीन पर जा रहे हैं';

  if (cmd.includes('passport') || cmd.includes('पासपोर्ट') || cmd.includes('photo') || cmd.includes('फोटो') || cmd.includes('बैकग्राउंड')) {
    target = 'photo-studio';
    message = 'फोटो स्टूडियो खोल रहे हैं...';
  } else if (cmd.includes('pdf') || cmd.includes('पीडीएफ') || cmd.includes('compress') || cmd.includes('मर्ज') || cmd.includes('दस्तावेज')) {
    target = 'pdf-studio';
    message = 'स्मार्ट पीडीएफ और डॉक्युमेंट स्टूडियो खोल रहे हैं...';
  } else if (cmd.includes('job') || cmd.includes('जॉब') || cmd.includes('नौकरी') || cmd.includes('भर्ती') || cmd.includes('sarkari') || cmd.includes('सरकारी')) {
    target = 'jobs';
    message = 'सरकारी नौकरी और शिक्षा अनुभाग खोल रहे हैं...';
  } else if (cmd.includes('csc') || cmd.includes('aadhaar') || cmd.includes('आधार') || cmd.includes('pan') || cmd.includes('पैन') || cmd.includes('राशन') || cmd.includes('जाति') || cmd.includes('आय')) {
    target = 'csc-services';
    message = 'सीएससी डिजिटल सेवा केंद्र खोल रहे हैं...';
  } else if (cmd.includes('invoice') || cmd.includes('बिल') || cmd.includes('रसीद') || cmd.includes('बिजनेस') || cmd.includes('विजिटिंग कार्ड') || cmd.includes('qr')) {
    target = 'business-tools';
    message = 'स्मार्ट बिजनेस टूल्स खोल रहे हैं...';
  } else if (cmd.includes('ai') || cmd.includes('असिस्टेंट') || cmd.includes('पूछो') || cmd.includes('सवाल') || cmd.includes('application') || cmd.includes('लिखो')) {
    target = 'ai-assistant';
    message = 'दीपक एआई असिस्टेंट खोल रहे हैं...';
  } else if (cmd.includes('file') || cmd.includes('फाइल') || cmd.includes('डाउनलोड') || cmd.includes('सेव्ड')) {
    target = 'my-files';
    message = 'माय फाइल्स खोल रहे हैं...';
  }

  return res.json({ target, message, originalCommand: command });
});

// 5. Jobs & Announcements API
app.get('/api/jobs', (_req, res) => {
  return res.json({ jobs: jobNotifications });
});

app.post('/api/admin/jobs', (req, res) => {
  const { title, department, totalPosts, qualification, ageLimit, lastDate, category, salary, officialUrl } = req.body;
  const newJob = {
    id: `job-${Date.now()}`,
    title: title || 'New Recruitment Update',
    department: department || 'Govt Department',
    totalPosts: totalPosts || 'TBD',
    qualification: qualification || '10th / 12th / Degree',
    ageLimit: ageLimit || '18-35 Years',
    lastDate: lastDate || '2026-12-31',
    category: category || 'Central',
    salary: salary || 'As per norms',
    officialUrl: officialUrl || 'https://www.india.gov.in',
    status: 'Active',
    featured: false,
  };
  jobNotifications.unshift(newJob);
  return res.json({ success: true, job: newJob });
});

app.get('/api/announcements', (_req, res) => {
  return res.json({ announcements: adminAnnouncements });
});

app.post('/api/admin/announcements', (req, res) => {
  const { title, message, type } = req.body;
  const newNotif = {
    id: `notif-${Date.now()}`,
    title: title || 'महत्वपूर्ण सूचना',
    message: message || '',
    date: 'अभी',
    type: type || 'alert',
  };
  adminAnnouncements.unshift(newNotif);
  return res.json({ success: true, announcement: newNotif });
});

// App configuration & status
app.get('/api/app-info', (_req, res) => {
  res.json({
    name: 'Deepak Smart App',
    tagline: 'आपका अपना डिजिटल स्मार्ट साथी',
    version: '2.5.0-PRO',
    developer: 'Deepak Smart Innovations India',
    email: 'deepakgayacsc@gmail.com',
    status: 'Online',
    aiStatus: ai ? 'Connected (Gemini 3.8 Flash)' : 'Ready (Fallback Active)',
  });
});

// Setup Vite or static serving
async function setupServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Deepak Smart App Server running on http://0.0.0.0:${PORT}`);
  });
}

setupServer().catch((err) => {
  console.error('Fatal server boot error:', err);
});
